# /prisma — Skill de Relatórios Interativos

Gera **relatórios HTML interativos e autocontidos** para audiências (executivos, stakeholders), com visualizações contendo gráficos interativos, filtros, navegação multi-página e carrossel. O output é sempre um único arquivo `.html` responsivo que você abre no browser e pode compartilhar por e-mail ou hospedar em qualquer lugar — sem dependências externas.

---

## Fontes de dados suportadas

| Fonte | Exemplos |
|---|---|
| Excel | `.xlsx`, `.xls` |
| Texto | `.csv`, `.txt` |
| Documentos | `.pdf`, `.docx` |
| Databricks | SQL queries, tabelas, views |
| Conteúdo livre | Cole dados diretamente no prompt |

---

## Componentes disponíveis

| Componente | Descrição |
|---|---|
| KPI Cards | Métricas em destaque no topo |
| ECharts | Gráficos interativos (linha, barra, pizza, scatter, heatmap, funil, gauge...) |
| Filtros | Por categoria e intervalo de datas, afetam todos os gráficos |
| Navegação multi-página | Abas ou menu lateral |
| Slideshow / Carrossel | Apresentação estilo PowerPoint com botões anterior/próximo |
| Tabelas interativas | Com ordenação e busca |

---

## Exemplos de uso

### Prompts de 1 linha — simples e diretos

```
/prisma Gera um dashboard executivo com o arquivo vendas_2025.xlsx
```

```
/prisma Transforma o relatorio_anual.pdf em um slideshow interativo
```

```
/prisma Cria um relatório com os dados da tabela sales.orders do Databricks
```

```
/prisma Analisa feedbacks_clientes.txt e monta um painel de NPS
```

---

### Prompts de exploração — analisa antes de gerar

Use quando não sabe exatamente o que quer. A skill analisa o arquivo e propõe estruturas antes de gerar qualquer HTML.

**Excel/CSV:**
```
/prisma

Analisa o arquivo vendas_2025.xlsx e me diz:
- Quais colunas existem e o que representam
- Que tipos de gráficos fazem sentido
- Que KPIs eu poderia destacar
- Sugestões de estrutura para um dashboard executivo

Não gera o relatório ainda, só me conta o que você viu.
```

**PDF:**
```
/prisma

Leia o arquivo relatorio_anual.pdf e me diz:
- Quais são os principais tópicos abordados
- Quais dados numéricos ou métricas aparecem
- Como você estruturaria isso em um slideshow de 6-8 slides

Aguarde minha aprovação antes de gerar qualquer HTML.
```

**Escolha de formato:**
```
/prisma

Tenho o arquivo dados_operacoes.csv. Analisa ele e me propõe
3 opções de relatório diferentes (dashboard, narrativo, slideshow),
explicando o que cada um destacaria. Eu escolho qual seguir.
```

**Iteração guiada:**
```
/prisma

Arquivo: metricas_q1.xlsx
Me resume o que tem nele em até 5 bullets.
Depois vou te dizer exatamente o que quero no relatório.
```

---

### Prompts personalizados — controle total

**Dashboard com Excel:**
```
/prisma

Arquivo: vendas_2025.xlsx — colunas: data, produto, região, valor, quantidade.

Quero um dashboard executivo com:
- KPIs: receita total, ticket médio, produtos únicos
- Gráfico de linha: receita por mês
- Gráfico de barra: top 10 produtos por receita
- Pizza: participação por região
- Filtros por região e por mês
- Tema: azul corporativo, logo no rodapé
```

**Slideshow executivo com PDF:**
```
/prisma

Arquivo: relatorio_2025.pdf
Transforma em uma apresentação interativa com:
- Slideshow carrossel de 8 slides com os principais achados
- Cada slide com título, texto resumido e um gráfico ilustrativo
- Botões de navegação anterior/próximo
- Tema executivo azul escuro
```

**Análise de NPS com arquivo de texto:**
```
/prisma

Arquivo: feedbacks_clientes.txt — um feedback por linha com nota NPS (0-10) e texto.

Quero:
- KPI: NPS score, % promotores / neutros / detratores
- Gráfico de distribuição das notas
- Nuvem de temas mais mencionados
- Tabela dos 20 feedbacks mais negativos
```

**Multi-página com CSV:**
```
/prisma

Arquivo: operacoes.csv — colunas: data, tipo, status, valor, agente.

Relatório com 3 páginas:
- Página 1: Visão geral (KPIs + gráfico de tendência)
- Página 2: Performance por agente (ranking + scatter)
- Página 3: Análise de status (funil + tabela detalhada)
Filtros globais por tipo e intervalo de datas.
```

**Slideshow sem arquivo — conteúdo textual livre:**
```
/prisma

Sem arquivo — quero um slideshow de 6 slides sobre resultados Q1 2025:
- Slide 1: Capa com título e data
- Slide 2: Resumo executivo (3 KPIs grandes)
- Slide 3: Gráfico de barras comparando Q1 vs Q1 anterior
- Slide 4: Mapa de calor de performance por região x produto
- Slide 5: Top 5 riscos (lista visual)
- Slide 6: Próximos passos
Tema: azul corporativo, logo da empresa no rodapé.
```

**Query no Databricks:**
```
/prisma

Conecta no Databricks e roda a query abaixo. Monta um dashboard executivo
com os resultados, destacando tendências e anomalias.

SELECT
  date_trunc('month', order_date) AS mes,
  region,
  SUM(revenue) AS receita,
  COUNT(DISTINCT customer_id) AS clientes
FROM sales.orders
WHERE order_date >= '2024-01-01'
GROUP BY 1, 2
ORDER BY 1, 2
```

**Dashboard multi-fonte (Databricks + arquivo):**
```
/prisma

Tenho duas fontes de dados:
1. Tabela Databricks: ops.incidents (id, data, severidade, time, tempo_resolucao)
2. Arquivo: metas_2025.xlsx com as metas mensais por time

Quero um relatório comparando performance real vs meta, com:
- KPI: incidentes totais, % dentro do SLA, tempo médio de resolução
- Linha: incidentes por mês com linha de meta sobreposta
- Barra: performance por time (real vs meta)
- Heatmap: severidade x dia da semana
- Filtros por severidade e por time
```

---

## Fluxo recomendado

```
1. Prompt simples ou de exploração  →  skill analisa o arquivo
2. Skill propõe estrutura            →  você ajusta ou aprova
3. Prompt detalhado                  →  skill gera o HTML final
```

---

## Dicas para melhores resultados

- **Descreva o público** — "para o board" vs "para o time de ops" muda o nível de detalhe
- **Indique o arquivo** — caminho completo ou cole as primeiras linhas
- **Especifique o tema** — cores, logo, estilo (dark / light / corporate)
- **Liste as páginas** — quantas abas/seções e o que cada uma mostra
- **Nomeie os gráficos** — tipo (linha, barra, pizza, scatter, heatmap, funil, gauge)
- **Diga "aguarde minha aprovação"** — para revisar a estrutura antes de gerar o HTML
