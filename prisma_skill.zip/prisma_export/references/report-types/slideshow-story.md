# Report Type — Slideshow Story

Use when the user asks for "slides", "slideshow", "presentation", "story", or "deck". This format presents insights one idea at a time, designed for projection or screen sharing to a non-technical audience.

## Layout

- **Aspect ratio:** 16:9. Frame size logical 1920x1080 using `vw`/`vh` units so it scales to any display.
- **Mobile fallback below 640px:** Each slide stacks its content vertically and fills 100% of viewport width with auto height. The 16:9 frame is dropped on mobile.
- **One viewport, no scroll** on desktop and tablet (`overflow-hidden`). Each slide is a full screen.
- **Wrapper:** `<div class="slide-deck w-screen h-screen overflow-hidden relative">` containing N `<section class="slide" data-slide-index="N">`.

## Slide Types

Mix these freely:

1. **Title slide** — hero text + subtitle + author/date. Optional full-bleed image.
2. **Big stat** — one giant number (`text-[12vw] font-black`) with a one-line caption.
3. **Headline + 3 bullets** — `<h2>` plus 3-5 short bullets. No more.
4. **Chart slide** — one chart taking 60% of the frame, with title above and 1-line takeaway below.
5. **Two-column comparison** — left side, right side, divider, takeaway at the bottom.
6. **Quote / callout** — single phrase in large type. Use sparingly.
7. **Section divider** — colored full-bleed background, section name centered.
8. **Closing slide** — recap of recommendations + contact / next steps.

## Typography Scale

| Element | Size | Weight |
|---|---|---|
| Hero headline | `text-[6vw]` | font-black |
| Slide headline | `text-[4vw]` | font-bold |
| Subheading | `text-[2.4vw]` | font-semibold |
| Body | `text-[1.6vw]` | font-medium |
| Caption | `text-[1.2vw]` | font-normal |
| Big stat number | `text-[10vw] sm:text-[12vw]` | font-black |

Mobile fallback: drop all `vw` sizes and use Tailwind defaults (`text-3xl`, `text-base`, etc.).

## Navigation

- **Keyboard:** ← / →, PageUp / PageDown, Space (advance), Esc (exit fullscreen).
- **Touch:** swipe left/right on mobile and tablet.
- **Mouse:** click left/right edge zones (200px wide), or use bottom-bar arrows.
- **Indicator:** thin progress bar at the top + "3 / 12" counter at bottom-right.
- **Overview mode:** press `O` or click an "Overview" button to see all slides as a grid of thumbnails. Click a thumb to jump.
- **Deep link:** `#slide-N` in the URL navigates to slide N on load.

## Hard Rules (copied from /skills/slides discipline)

- One idea per slide. If the headline contains "and", split into two slides.
- Maximum 6 lines of text per slide.
- Maximum 2 fonts (1 display, 1 body), 3 weights total.
- Minimum body font size: `1.5vw` (≥ 24px at 1920x1080).
- No animations on slide content. Slide-to-slide transition is a simple 200ms fade.
- No emojis.
- No AI-slop language (see `references/voice/anti-ai-slop.md`).
- No interactive widgets except the chart itself, navigation, and external links.

## Chart Slides

When a slide hosts a chart:

- Title above (`text-[3vw] font-bold mb-[1.5vh]`).
- Chart fills `w-[80%] h-[60%]` centered.
- Below the chart: one-line takeaway (`text-[1.6vw] text-zinc-600 dark:text-zinc-400`).
- Legend block (source, definition, unit, period) in the bottom-left at `text-[0.9vw]`.

## Mobile Adaptation

Below 640px:

- The 16:9 frame is replaced by a vertical stacked layout. Each slide becomes a full-width card with `min-h-screen` and natural padding.
- Navigation arrows move to a fixed bottom bar.
- Swipe gestures still work.
- Charts use `aspect-[4/3]` instead of `60% of frame`.
- Big stat numbers cap at `text-7xl` to avoid overflow.

## Print

- Each slide becomes one printed page (`@page { size: landscape; margin: 0 }`).
- `break-after: page` on each `.slide`.
- Hide navigation controls.
- Force light mode.

## Required Controls

- Keyboard help overlay (press `?`).
- Dark mode toggle.
- Print/export PDF button.
- Overview mode toggle.

## Slide Manifest

For maintenance, write a `data/slides-manifest.json` alongside the HTML:

```json
{
  "slides": [
    { "index": 1, "type": "title", "title": "Q4 Sales Story" },
    { "index": 2, "type": "big-stat", "title": "Revenue: $2.4M" },
    { "index": 3, "type": "chart", "title": "Trend by region" },
    ...
  ]
}
```

This is for the user to navigate the source if they want to edit slides later.

## Anti-Patterns

- Do NOT use loops to generate many slides — write each slide as static markup so the user can edit individually.
- Do NOT use pie charts in slides (hard to read at distance). Use bar charts.
- Do NOT put more than one chart per slide.
- Do NOT use small text. Anything below `1.5vw` is rejected at validation.
