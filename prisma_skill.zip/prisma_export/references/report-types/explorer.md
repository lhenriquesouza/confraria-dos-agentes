# Report Type — Dataset Explorer

Use when the user wants to "explore", "investigate", "filter", or "drill down" on a dataset. The explorer prioritizes interactive filtering with everything reactive.

## Layout

- **Container:** `max-w-[1600px] mx-auto`. Widest of all report types.
- **Header:** Title, source badges, controls.
- **Three-pane layout on `lg+`:**
  - Left sidebar (280px fixed): all filters, grouped by type.
  - Main area: charts grid + data table.
  - Right rail (280px, optional): selected-row inspector or drill-down detail.
- **Below `lg`:** Filter sidebar collapses into a drawer; right rail moves to a bottom modal.

## Filter Panel

Group filters into collapsible sections:

1. **Time range** — date range picker with presets.
2. **Categorical filters** — one card per categorical column (≤30 uniques: chip list; >30 uniques: search combobox).
3. **Numeric filters** — range sliders for the 3 most informative numeric columns.
4. **Search** — full-text search across string columns.
5. **Saved views** — local-storage-backed filter combinations (default views: "All", "Last 30 days", "Top 10").

Active filters appear as removable chips above the main area, with a "Clear all" button.

## Main Area

Stack of:

1. **KPI strip** — recomputes live from filtered rows. Shows 4 metrics with delta vs the unfiltered baseline.
2. **Chart grid** — `grid grid-cols-1 lg:grid-cols-2 gap-4`. Charts react to filters within ~100ms (precomputed indices in JS).
3. **Data table** — TanStack-style with sortable headers, sticky header row, pagination (50/100/200 rows per page), CSV export of the current view.

## Right Rail (Drill-Down)

When the user clicks a row in the table or a data point in a chart:

- Right rail slides in (or modal on mobile) showing all fields of that record.
- Related records (matched by foreign-key heuristics: column names ending in `_id` shared with another table or with itself).
- A "Show all from this category" button that adds a filter and clears the rail.

## Mobile Behavior (< 1024px)

- Filter panel becomes a full-screen drawer triggered by a "Filters (N)" button.
- Right rail becomes a bottom sheet.
- KPI strip stays as 2x2 grid.
- Chart grid stacks to 1 column.
- Table stays scrollable; sticky first column.

## Required Controls

- Dark mode toggle.
- Print/export current view to PDF.
- CSV export of the filtered dataset (whole, not paginated).
- "Reset filters" button.
- Active-filter count badge in the header.

## Performance

- For datasets > 5000 rows, pre-compute filter indices in JS using `Map<columnValue, Set<rowIndex>>`. Avoid scanning all rows on every filter change.
- Debounce the search input by 200ms.
- Use `IntersectionObserver` to lazy-init ECharts instances that are below the fold.

## Anti-Patterns

- Do NOT auto-apply filters as the user types in non-search fields. Use explicit "Apply" only when there are >5 active filters and the dataset is huge.
- Do NOT show more than 8 charts. If more would help, switch to multi-page.
- Do NOT use modals for primary content. Use the right rail or inline expansion.
