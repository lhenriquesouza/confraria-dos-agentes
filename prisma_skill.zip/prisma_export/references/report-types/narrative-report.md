# Report Type — Narrative Report

Use when the user asks for a "report", "analysis", "writeup", or wants explanation, not just monitoring. The structure mirrors a McKinsey-style executive memo.

## Layout

- **Container:** `max-w-[920px] mx-auto px-4 sm:px-6 lg:px-8`. Narrower than a dashboard for readability.
- **Header:** Report title, subtitle, author/date, controls (dark toggle, print).
- **Executive summary:** 3–5 bullet points at the top. The reader can stop here and still know the answer.
- **Sections:** One per key finding. Each section follows the pattern: headline → 1-paragraph context → embedded chart or KPI strip → 1-paragraph implication → optional callout box for recommendations.
- **Recommendations block:** At the end. Numbered, action-oriented.
- **Methodology block:** Last. Explains data sources, filters applied, caveats.

## Executive Summary Pattern

```
Executive summary

- [Headline finding #1, one sentence with the number embedded.]
- [Headline finding #2.]
- [Headline finding #3.]
- [Recommendation in one line.]
```

Maximum 5 bullets. Each bullet must contain a concrete number, not generalities.

## Section Anatomy

Each section is a `<section>` block:

1. `<h2>` — sentence-case headline that states the finding (not a topic). Bad: "Sales". Good: "Sales fell 8% in Q4 because of the European region".
2. Context paragraph (2–4 sentences) — what was happening before, what the comparison is.
3. Visual — one chart (preferred) or one KPI strip. Wrapped in a `<figure>` with mandatory `<figcaption>` legend.
4. Implication paragraph (1–3 sentences) — what this means for the reader's decisions.
5. Optional callout: "What to do about it" — boxed recommendation.

## Visual Cadence

- Maximum one main visual per section.
- Alternate visual types across sections (avoid 5 line charts in a row).
- Use horizontal rules (`<hr class="my-12 border-zinc-200 dark:border-zinc-800">`) between sections.

## Mobile Behavior (< 640px)

- Charts use `aspect-[4/3]` instead of `aspect-[16/9]` to keep height manageable.
- Sections collapse padding to `py-8` instead of `py-12`.
- Callout boxes stack to full width.
- Inline KPI strips become a 2-column grid instead of a 4-column row.

## Print Behavior

- Page break before each `<h2>` section.
- `break-inside: avoid` on figures and callout boxes.
- Hide all controls (`print:hidden`).
- Force light mode in print.
- Show URL of the report in the footer of each page (CSS `@page` `@bottom-right`).

## Required Controls

- Dark mode toggle.
- Print to PDF button.
- "Jump to section" dropdown (becomes a sticky table of contents on `lg+`).

## Anti-Patterns

- Do NOT pad with filler text. Empty space is fine; vague text is not.
- Do NOT split a single finding across two sections.
- Do NOT use bullet lists when prose flows better. Use bullets only for parallel items.
- Do NOT end on the methodology. End on the recommendation; methodology is reference material.
