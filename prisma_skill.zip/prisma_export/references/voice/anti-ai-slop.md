# Anti-AI-Slop — Banned Words and Style Guard

The fastest way to make a report look generated is to fill it with hollow buzzwords. This list is the strike-on-sight vocabulary. The validator scans the rendered HTML for these words and fails the build if any are found.

## Banned Words (case-insensitive, word-boundary)

| Word | Why it is banned |
|---|---|
| magic | Vague mysticism. Replace with the actual mechanism. |
| delight | Marketing fluff. Replace with the concrete benefit. |
| seamless | Empty. Describe what the experience actually does. |
| unlock | Overused. Use "enable", "let", or describe the action. |
| rethink | Vague. State what specifically should change. |
| supercharge | Marketing fluff. State the change. |
| leverage | Use "use". |
| empower | Use "let" or "enable". |
| game-changer | Cliché. State what changed. |
| revolutionize | Cliché. State the change. |
| transform | Cliché. State the specific transformation. |
| synergy | Empty. State the specific overlap or benefit. |
| paradigm | Empty. State the specific approach. |
| robust | Vague. State the actual properties. |
| holistic | Vague. State the dimensions covered. |
| disruptive | Cliché. State what is being changed. |
| cutting-edge | Cliché. State the actual technology or method. |
| world-class | Empty. Compare to specific peers. |
| best-in-class | Empty. Cite the comparison. |
| streamline | Vague. State the specific simplification. |
| optimize | Vague. State what is being changed and by how much. |
| empower(s|ed|ing) | (regex) all forms |
| leverage(s|d|ing) | (regex) all forms |

## Banned Phrases

- "It is important to note that..." — cut, then state the fact.
- "Interestingly,..." — cut.
- "As we can see..." — cut.
- "In today's fast-paced world..." — cut.
- "Going forward..." — replace with a specific time period.
- "At the end of the day..." — cut.
- "Moving the needle" — replace with the metric and direction.
- "Low-hanging fruit" — replace with the specific opportunity.

## No Emojis

Zero emojis appear in any rendered report. Zero emojis in any skill file. The validator scans for any character in Unicode emoji ranges and fails the build if any are found.

This is non-negotiable. Even for "fun" reports.

## Replacement Patterns

| Slop | Concrete replacement |
|---|---|
| "We unlock new opportunities" | "We added 12 new product categories in Q4" |
| "Seamless customer journey" | "Checkout takes 2 fewer steps than in Q3" |
| "Leverage our data" | "Use sales data" |
| "Empower the team" | "Let the team decide" |
| "Optimize performance" | "Reduce page load from 3.2s to 1.4s" |
| "Game-changing results" | "Revenue up 12% vs Q3" |

## Tone Guardrails

- **Direct.** Subject + verb + object. Avoid passive voice unless the actor is unknown.
- **Concrete.** Every claim has a number, a name, or a date attached.
- **Honest.** If the data is weak, say so. If you do not know, say so.
- **Calibrated.** Use "may", "could", "is likely to" only when the data genuinely supports uncertainty.
- **Brief.** Every sentence earns its place. Cut anything that does not.

## Validation

`scripts/validate_report.py` runs:

```python
banned = [r"\bmagic\b", r"\bdelight\b", r"\bseamless\b", r"\bunlock\w*\b",
          r"\brethink\w*\b", r"\bsupercharge\w*\b", r"\bleverag\w*\b",
          r"\bempower\w*\b", r"\bgame[-\s]?changer\b", r"\brevolutioni[sz]e\b",
          r"\btransform\b", r"\bsynerg\w*\b", r"\bparadigm\b",
          r"\brobust\b", r"\bholistic\b", r"\bdisruptive\b",
          r"\bcutting[-\s]edge\b", r"\bworld[-\s]class\b", r"\bbest[-\s]in[-\s]class\b",
          r"\bstreamlin\w*\b", r"\boptimi[sz]\w*\b"]
emoji_re = re.compile(r"[\U0001F300-\U0001FAFF\U00002600-\U000027BF\U0001F600-\U0001F64F]")
```

The check applies to the rendered text inside `<body>`, ignoring code fences and `<script>` blocks.

If any match is found, the validator prints the line and the offending word. Fix the report and re-run validation.

## Why This Matters

A report that reads like a press release loses the audience's trust within two paragraphs. A report that reads like a sharp colleague's email keeps it. The vocabulary above is the difference.
