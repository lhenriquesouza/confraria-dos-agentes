# Non-Technical Audience — Voice and Vocabulary

The reader is a senior business stakeholder, an executive, a board member, or a team manager. They are intelligent and busy. They are not a developer or a data scientist.

## Core Rules

1. **Lead with the answer.** Then evidence. Then context.
2. **Inline-define every technical term on first use.** Do not assume the reader knows acronyms.
3. **Replace jargon with plain language.** "Throughput" → "items processed per hour". "Cohort" → "group of users that signed up the same week".
4. **Use concrete numbers, not vague magnitudes.** "Up 12% to $2.4M" not "significantly higher".
5. **Direction always paired with baseline.** "12% higher than Q3" not just "12%".
6. **Use the audience's locale.** Currency symbol, number format, date format, language all match the user's context.

## Vocabulary Substitutions

| Avoid | Use |
|---|---|
| Throughput | Items processed per hour |
| Latency | Response time |
| Conversion rate | Percentage of visitors who bought |
| Churn | Customers who left |
| Cohort | Group of customers from the same period |
| Retention curve | Percentage still active over time |
| LTV / CLV | Average revenue per customer over their lifetime |
| MAU / DAU / WAU | Monthly / daily / weekly active users |
| ARPU | Average revenue per user |
| ETL pipeline | Data processing job |
| Database query | Data lookup |
| Aggregate | Combined total |
| Stochastic | Random |
| Heuristic | Rule of thumb |
| Outlier | Unusual value |
| Distribution | Spread of values |

If a technical term is the most accurate one, use it AND inline-define on first use.

## Inline Definition Pattern

```
"Average order value (total revenue divided by number of orders) declined to $84 in Q4..."
```

The definition is in parentheses, in plain language, no longer than 12 words.

## Number Formatting

Per locale (default en-US; switch to user's locale if data hints otherwise):

| Concept | en-US | pt-BR |
|---|---|---|
| Thousand separator | `,` | `.` |
| Decimal separator | `.` | `,` |
| Currency | `$1,234.56` | `R$ 1.234,56` |
| Date | `May 5, 2026` | `5 de maio de 2026` |
| Short date | `05/05/2026` (M/D/Y) | `05/05/2026` (D/M/Y) |

For datasets where locale is ambiguous, default to the user's prompt language.

## Magnitude Shortening

For KPI big numbers and chart axes:

| Raw | Shortened |
|---|---|
| 1,200 | 1.2k |
| 12,000 | 12k |
| 1,200,000 | 1.2M |
| 1,200,000,000 | 1.2B |

In tables and tooltips, use the full number with separators.

## Time Horizons

Use natural-language periods alongside dates:

- "Last quarter (Oct 1 – Dec 31, 2025)"
- "First half of 2025 (Jan 1 – Jun 30)"
- "Last 30 days (Apr 5 – May 5, 2026)"

Never assume the reader will compute the date range from a label like "Q4".

## Audience Calibration by Phrasing

| Audience hint | Tone shift |
|---|---|
| "for the board" | More formal, more emphasis on macro KPIs and recommendations |
| "for the team" | More tactical, more "what to do this week" |
| "for marketing" | Frame insights around channels, campaigns, conversion |
| "for finance" | Frame around revenue, cost, margin, period comparisons |
| "for product" | Frame around features, usage funnels, retention |

If the audience is not specified, default to "senior leadership". This is the safest middle ground.

## Glossary Generation

The skill always generates a glossary. Every term used in the report that is not common business English appears in the glossary. The glossary is reachable from a footer link and from the help button in the header.

## Examples — Rewriting Technical Captions

| Technical caption | Rewritten for non-technical audience |
|---|---|
| "Sum of `amount` grouped by `region` for `order_date >= 2025-10-01`" | "Total revenue by region in Q4 2025" |
| "p95 of response_time, daily" | "Daily response time at the 95th percentile (the slowest 5% of requests)" |
| "User retention by acquisition cohort" | "Percentage of users still active, grouped by the week they signed up" |
| "Heatmap of order count by hour and day-of-week" | "When do customers order? Number of orders by hour of the day and day of the week" |

## Final Test

Before delivering, read the report out loud as if you were presenting it. If you stumble on any sentence, rewrite it. If you find yourself explaining a chart in different words, the chart caption is wrong; fix the caption.
