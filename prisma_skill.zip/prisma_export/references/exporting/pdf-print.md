# PDF / Print Export

Reports are designed to print well from the browser. No external PDF library required.

## How the User Exports

The header has a "Print or save as PDF" button that calls `window.print()`. The browser's native dialog appears. The user picks "Save as PDF" or sends to a printer.

## Print Stylesheet

Embedded in every report. Already covered in `references/ui/responsive-layout.md`. Recap:

```css
@media print {
  @page { size: A4; margin: 12mm; }
  html { background: white !important; }
  body { color: black !important; background: white !important; }
  .print\:hidden { display: none !important; }
  figure, .card, section { break-inside: avoid; }
  h1, h2, h3 { break-after: avoid; }
  /* Force light mode regardless of dark toggle */
  html.dark { color-scheme: light; }
  html.dark body { background: white !important; color: black !important; }
  html.dark .bg-zinc-950, html.dark .bg-zinc-900 { background: white !important; }
  html.dark .text-zinc-100, html.dark .text-zinc-200 { color: black !important; }
  html.dark .border-zinc-800 { border-color: #e4e4e7 !important; }
  /* Show URLs of links */
  a[href^="http"]:after { content: " (" attr(href) ")"; font-size: 0.85em; color: #555; }
}
```

## Slideshow Print

Each slide becomes one landscape page:

```css
@media print {
  body.slideshow { background: white; }
  .slide-deck { display: block; height: auto; overflow: visible; }
  .slide {
    position: relative !important;
    opacity: 1 !important;
    z-index: auto !important;
    pointer-events: auto !important;
    width: 100vw; height: 100vh;
    break-after: page;
    page-break-after: always;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  @page { size: A4 landscape; margin: 0; }
  .slide-deck > .absolute.top-0,
  .slide-deck > .absolute.bottom-0,
  .slide-deck > .absolute.left-0,
  .slide-deck > .absolute.right-0 { display: none !important; }
}
```

## Chart Rendering for Print

ECharts canvas rendering produces correct print output. SVG rendering can break in some browsers. Stick with `renderer: 'canvas'` (the default in our recipes).

Animations are off (`animation: false`), so charts render their final state immediately, which is what print captures.

## Pre-Print Hook

Right before the print dialog opens, force ECharts to resize so the chart fits the new page width:

```js
window.addEventListener('beforeprint', () => {
  // ECharts needs an explicit resize when the viewport changes for print
  document.querySelectorAll('.echarts-target').forEach(el => {
    const inst = echarts.getInstanceByDom(el);
    if (inst) inst.resize();
  });
});
```

## Page Header / Footer

Set via `@page` margins and `position: running()` is not portable across browsers. Instead:

- Repeat the report title and page number using a small fixed bar inside `body`:

```html
<div class="hidden print:block fixed top-0 left-0 right-0 px-3 py-1 text-[9px] text-zinc-500
            border-b border-zinc-200">
  {{ reportTitle }} · Generated {{ generatedAt }}
</div>
```

The browser's print engine will not repeat this on every page automatically. To get repeating headers, use `position: fixed` and let the browser repeat (Chromium honors this; Firefox may not). Document this caveat in the methodology section if it matters.

## Limitations

- Interactive elements (filters, dark toggle, expand) are hidden in print.
- The slideshow overview grid is hidden in print.
- Tooltips do not appear in print (they are mouse-driven).
- Sticky elements behave inconsistently across browsers in print mode. Test on Chromium and Safari.

## Locale / Paper Size

Default is A4. For US Letter:

```css
@media print { @page { size: letter; margin: 0.5in; } }
```

The skill picks A4 unless the user is clearly US-based (locale detection from the user's prompt language or explicit hint).
