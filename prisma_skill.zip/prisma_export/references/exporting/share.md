# Sharing the Report

The skill produces local files. The user shares them however they prefer (email, drive, internal portal). This file describes how to choose between standalone vs multi-file delivery.

## Decision Matrix

| Condition | Output | Notes |
|---|---|---|
| Single dashboard or narrative report; dataset < 400 KB inline | **Standalone single HTML file** | One file, fully self-contained. Easy to email or attach. |
| Slideshow story; dataset < 400 KB inline | **Standalone single HTML file** | Same advantages. Mobile fallback included. |
| Multi-page report (>1 page) | **Multi-file folder** | Index + per-topic pages + shared assets. Requires hosting or zip. |
| Dataset > 400 KB | **Multi-file folder** | Dataset moves to `data/dataset.json`, fetched on load. |
| User explicitly asks for "files" or "a folder" or "to host" | **Multi-file folder** | Honor user intent. |
| User explicitly asks for "one file" or "to email" | **Standalone single HTML file** | Honor user intent. |

## Standalone Output

Path: `./prisma-output/<slug>/<slug>.html`

Self-contained: Tailwind via CDN, ECharts via CDN, Alpine via CDN, dataset embedded as JSON in `<script id="report-data" type="application/json">`. No relative file dependencies.

How to open:

- macOS: `open ./prisma-output/<slug>/<slug>.html`
- Linux: `xdg-open ./prisma-output/<slug>/<slug>.html`
- Windows: `start ./prisma-output/<slug>/<slug>.html`

How to share: attach the HTML file. The recipient opens it in any modern browser. No installation, no server.

## Multi-File Output

Path: `./prisma-output/<slug>/`

Structure (see `references/ui/multi-page-nav.md`):

```
<slug>/
├── index.html
├── pages/...
├── assets/css/, assets/js/
└── data/
```

How to open:

- Recommended: serve with a simple HTTP server because some browsers block `fetch('data/...')` from `file://` URLs.
  - `python -m http.server 8000` from inside the folder, then visit `http://localhost:8000/`.
- Quick share: zip the folder (`zip -r <slug>.zip <slug>/`) and send.
- Hosted share: drop the folder into S3, GitHub Pages, Netlify, Vercel, Cloudflare Pages, or any static host.

## Always Output These

After delivery, the skill prints a final block:

```
Report generated.

Path: ./prisma-output/<slug>/
Entry point: ./prisma-output/<slug>/<slug>.html  (or index.html for multi-file)

Open locally:
  open ./prisma-output/<slug>/<slug>.html        # macOS
  xdg-open ./prisma-output/<slug>/<slug>.html    # Linux
  start ./prisma-output/<slug>/<slug>.html       # Windows

Or serve (multi-file only):
  cd ./prisma-output/<slug>/
  python -m http.server 8000
  # then open http://localhost:8000/

Print to PDF: open in browser, click the printer icon in the header,
then choose "Save as PDF".
```

## Privacy Notes

- The HTML contains the dataset embedded inline. Do not share with anyone who should not see the source data.
- Credentials are never written into the output. The validator double-checks for common credential patterns (`DATABRICKS_TOKEN=`, `Bearer `, `password:`).
- The methodology section names the source. Confirm with the user before sharing externally.

## Versioning

If the user re-runs the skill on the same topic, append a timestamp suffix:

```
./prisma-output/<slug>-2026-05-05-1042/
```

Do not overwrite previous outputs without asking.
