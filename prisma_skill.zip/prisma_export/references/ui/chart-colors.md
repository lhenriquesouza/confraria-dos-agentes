# Chart Colors — Palette and Semantic Rules

Use this palette for every chart. Do not invent colors unless the user provided a custom branding source.

## Base Palette

```js
const CHART_COLORS = {
  blue:   "#0079F2",  // primary, default for any single series
  purple: "#795EFF",  // secondary, used in 2-series comparisons
  green:  "#009118",  // positive (only when semantically positive)
  red:    "#A60808",  // negative (only when semantically negative)
  amber:  "#D97706",  // warning / attention
  pink:   "#EC4899",  // accent (rare)
  teal:   "#0D9488",  // additional category
  slate:  "#64748B",  // neutral / "Other"
};

const CHART_COLOR_LIST = [
  CHART_COLORS.blue,
  CHART_COLORS.purple,
  CHART_COLORS.teal,
  CHART_COLORS.amber,
  CHART_COLORS.pink,
  CHART_COLORS.green,
  CHART_COLORS.red,
  CHART_COLORS.slate,
];
```

Export this as a `<script>` block at the top of every report so charts and KPI cards reference the same constants.

## Assignment Rules

| Number of series | Colors |
|---|---|
| 1 | `blue` |
| 2 (comparison) | `blue`, `purple` |
| 2 (positive vs negative) | `green`, `red` |
| 3 | `blue`, `purple`, `teal` |
| 4-8 | `CHART_COLOR_LIST` in order |
| 9+ | Use a sequential or diverging scale (see below) |

## Semantic Color Use

- **Green** only for semantically positive values: revenue growth, conversion increases, retention up.
- **Red** only for semantically negative values: churn, errors, drops.
- **Amber** for neutral attention: outliers, warnings, threshold crossings.
- **Slate / gray** for "Other", "Unknown", or aggregated tail categories.

Never assign green or red just for visual variety.

## Sequential and Diverging Scales (for heatmaps, choropleth)

```js
// Sequential (low → high of one metric)
const SEQUENTIAL = ['#EFF6FF', '#BFDBFE', '#60A5FA', '#2563EB', '#1E40AF'];

// Diverging (negative ← 0 → positive)
const DIVERGING = ['#A60808', '#F87171', '#F4F4F5', '#60A5FA', '#0079F2'];
```

## Dark Mode Adjustments

Charts read theme via a `data-theme` attribute on `<html>`. Adjust:

- Axis lines: `#E4E4E7` (light) / `rgba(255,255,255,0.12)` (dark).
- Axis labels: `#71717A` (light) / `#A1A1AA` (dark).
- Grid lines: `#F4F4F5` (light) / `rgba(255,255,255,0.06)` (dark).
- Tooltip background: `#FFFFFF` (light) / `#18181B` (dark).
- Tooltip border: `#E4E4E7` (light) / `#3F3F46` (dark).

Series colors stay the same in both themes — they are tuned to be readable on both backgrounds.

## Color Discipline

> Calm does not mean colorless. Use real color derived from the report's identity. Calm means the color is soothing, not absent. Never accept pure white backgrounds with gray text as a finished palette — that is a wireframe, not a product.

- Do NOT use rainbow palettes for categorical data with no order.
- Do NOT use red/green as the only differentiator. Pair them with shape or label so color-blind users can read the chart.
- Do NOT use light pastels on white backgrounds. Use the saturated palette above.

## Custom Branding

If the user provided a branding source (URL, image, palette JSON):

1. Use `WebFetch` to fetch the URL.
2. Extract dominant colors with simple heuristics (or ask the user to confirm a 5-color palette).
3. Override `CHART_COLORS.blue` and `CHART_COLORS.purple` with the brand primary and secondary.
4. Keep `green`, `red`, `amber` as semantic colors regardless of brand.
5. Document the override at the top of the report: `Brand palette applied from <source>`.
