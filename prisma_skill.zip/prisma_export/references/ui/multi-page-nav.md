# Multi-Page Navigation

Use multi-page mode when the data has 2+ uncorrelated themes (e.g. revenue, support, product usage) and total content would exceed one comfortable scroll on desktop.

## When to Use Multi-Page

- The analyzer detects ≥2 distinct topic clusters (different sets of dimensions).
- The single-page version would have more than 8 charts.
- The user explicitly asks for "sections" or "tabs".

If the topics are correlated (e.g. revenue + AOV + units), keep them on one page. Multi-page is for separation, not chunking.

## File Structure

```
prisma-output/<slug>/
├── index.html                    # Hub: title, exec summary, link cards to each page
├── pages/
│   ├── overview.html
│   ├── <topic-1>.html
│   ├── <topic-2>.html
│   └── ...
├── assets/
│   ├── css/custom.css
│   ├── js/app.js                 # shared theme, nav, glossary
│   ├── js/charts.js              # chart factory functions
│   └── js/filters.js
└── data/
    ├── dataset.json              # full dataset
    └── analysis.json             # statistical analysis output
```

Each page is a complete standalone HTML that loads `assets/` and `data/`. Same shell, different content.

## Navigation Component

A consistent nav lives at the top of every page, plus a sidebar on `lg+` for the explorer-style multi-page reports.

### Top nav (default)

```html
<nav class="sticky top-0 z-30 bg-white/80 dark:bg-zinc-950/80 backdrop-blur
            border-b border-zinc-200 dark:border-zinc-800 print:hidden">
  <div class="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8
              flex items-center justify-between gap-4 h-14 sm:h-16">
    <a href="../index.html" class="flex items-center gap-2 min-w-0">
      <span class="font-semibold truncate">{{ reportTitle }}</span>
    </a>
    <!-- Desktop links -->
    <ul class="hidden md:flex items-center gap-1">
      <template x-for="page in pages">
        <li>
          <a :href="page.href"
             class="px-3 py-2 rounded-md text-sm font-medium min-h-[40px]
                    inline-flex items-center"
             :class="page.active
               ? 'bg-zinc-100 dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100'
               : 'text-zinc-600 dark:text-zinc-400 hover:bg-zinc-50 dark:hover:bg-zinc-900'"
             x-text="page.label"></a>
        </li>
      </template>
    </ul>
    <!-- Right cluster -->
    <div class="flex items-center gap-2">
      <!-- header controls (theme, print) -->
      <button class="md:hidden min-h-[44px] min-w-[44px]"
              aria-label="Open menu" @click="mobileMenuOpen = true">
        <svg class="w-5 h-5"><!-- hamburger icon --></svg>
      </button>
    </div>
  </div>
</nav>

<!-- Mobile drawer -->
<div x-show="mobileMenuOpen" x-cloak class="fixed inset-0 z-50 md:hidden"
     @keydown.escape.window="mobileMenuOpen = false">
  <div class="absolute inset-0 bg-black/40" @click="mobileMenuOpen = false"></div>
  <div class="absolute right-0 top-0 bottom-0 w-[85vw] max-w-sm
              bg-white dark:bg-zinc-950 p-4 overflow-y-auto">
    <div class="flex items-center justify-between mb-4">
      <span class="font-semibold">Menu</span>
      <button class="min-h-[44px] min-w-[44px]" @click="mobileMenuOpen = false">×</button>
    </div>
    <ul class="space-y-1">
      <template x-for="page in pages">
        <li>
          <a :href="page.href"
             class="block px-3 py-3 rounded-lg text-base min-h-[48px]"
             :class="page.active ? 'bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-300'
                                 : 'text-zinc-700 dark:text-zinc-300'"
             x-text="page.label"></a>
        </li>
      </template>
    </ul>
  </div>
</div>
```

### Sidebar nav (for explorer-style multi-page)

```html
<aside class="hidden lg:block sticky top-16 self-start w-64 shrink-0
              border-r border-zinc-200 dark:border-zinc-800 h-[calc(100vh-4rem)] overflow-y-auto">
  <nav class="p-3 space-y-1">
    <template x-for="page in pages">
      <a :href="page.href" class="flex items-center gap-2 px-3 py-2 rounded-md text-sm
                                  min-h-[40px]"
         :class="page.active
           ? 'bg-zinc-100 dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100'
           : 'text-zinc-600 dark:text-zinc-400 hover:bg-zinc-50 dark:hover:bg-zinc-900'">
        <span x-text="page.label"></span>
        <span x-show="page.count" class="ml-auto text-xs text-zinc-400" x-text="page.count"></span>
      </a>
    </template>
  </nav>
</aside>
```

On `<lg`, the sidebar collapses into the same drawer pattern as the top-nav mobile menu.

## Hub Page (`index.html`)

The first page the user lands on:

- Report title and subtitle.
- Executive summary (3-5 bullets across all pages).
- Source badges.
- A grid of "section cards" — one per page, with icon, name, 1-line description, and the headline KPI from that section.
- Footer.

```html
<main class="max-w-[1100px] mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
  <h1 class="text-2xl sm:text-4xl font-bold mb-3">{{ reportTitle }}</h1>
  <p class="text-base sm:text-lg text-zinc-600 dark:text-zinc-400 mb-8">{{ subtitle }}</p>

  <section class="mb-10 sm:mb-14">
    <h2 class="text-lg font-semibold mb-3">Executive summary</h2>
    <ul class="space-y-2 text-base sm:text-lg">
      {% for bullet in executiveSummary %}
        <li class="flex gap-3">
          <span class="text-blue-600 dark:text-blue-400 font-bold mt-1">·</span>
          <span>{{ bullet }}</span>
        </li>
      {% endfor %}
    </ul>
  </section>

  <section>
    <h2 class="text-lg font-semibold mb-4">Sections</h2>
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
      {% for page in pages %}
        <a href="{{ page.href }}" class="block p-5 sm:p-6 rounded-2xl border
                  border-zinc-200 dark:border-zinc-800 hover:border-blue-300
                  dark:hover:border-blue-700 transition-colors">
          <div class="text-xs text-zinc-500 mb-1">{{ page.label }}</div>
          <div class="text-2xl sm:text-3xl font-bold mb-2">{{ page.headlineKpi }}</div>
          <div class="text-sm text-zinc-600 dark:text-zinc-400">{{ page.description }}</div>
        </a>
      {% endfor %}
    </div>
  </section>
</main>
```

## Routing

No JS router. Pure HTML links. `<a href="pages/topic-1.html">`. The browser handles back/forward natively.

For deep links to specific anchors within a page, use standard fragment URLs (`pages/topic-1.html#kpis`).

## Shared State Across Pages

Pages share theme and last-active filters via `localStorage` (key prefix `prisma-reports.<slug>.`). Read on each page load:

```js
const storageKey = `prisma-reports.${slug}`;
const sharedFilters = JSON.parse(localStorage.getItem(`${storageKey}.filters`) || '{}');
```

Do not try to share scroll position. It causes confusion.

## Mobile Behavior

- Top nav becomes a logo + hamburger.
- Hub-page section cards stack to 1 column.
- Sidebar nav becomes a drawer.
- Active page link is highlighted.

## Accessibility

- Add `aria-current="page"` to the active nav link.
- Ensure keyboard focus order matches visual order.
- Drawer trap focus when open.
- ESC closes drawer.
