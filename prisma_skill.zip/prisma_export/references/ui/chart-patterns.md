# Chart Patterns — ECharts Recipes

Use Apache ECharts via CDN: `https://cdn.jsdelivr.net/npm/echarts@5/dist/echarts.min.js`. Every chart uses these defaults.

## Universal Defaults

```js
function baseOption(theme) {
  const isDark = theme === 'dark';
  return {
    animation: false, // disable animations for performance and print
    grid: { top: 40, right: 24, bottom: 40, left: 56, containLabel: true },
    textStyle: { fontFamily: 'Inter, system-ui, sans-serif' },
    tooltip: {
      trigger: 'axis',
      backgroundColor: isDark ? '#18181B' : '#FFFFFF',
      borderColor: isDark ? '#3F3F46' : '#E4E4E7',
      borderWidth: 1,
      textStyle: { color: isDark ? '#F4F4F5' : '#18181B' },
      extraCssText: 'box-shadow: 0 8px 24px rgba(0,0,0,.08); border-radius: 8px;',
    },
    legend: {
      bottom: 0,
      icon: 'roundRect',
      itemWidth: 12,
      itemHeight: 12,
      textStyle: { color: isDark ? '#A1A1AA' : '#52525B', fontSize: 12 },
    },
  };
}
```

## Initialization Pattern

```js
function initChart(targetEl, option) {
  const chart = echarts.init(targetEl, null, { renderer: 'canvas' });
  chart.setOption(option);
  // Resize on window resize and on container resize
  const ro = new ResizeObserver(() => chart.resize());
  ro.observe(targetEl);
  // Theme switch
  document.documentElement.addEventListener('themechange', (e) => {
    chart.setOption(applyTheme(option, e.detail.theme));
  });
  return chart;
}
```

Always observe the container with `ResizeObserver`. Window resize alone is not enough for grid layouts.

## Chart Recipes

### 1. Line (time series, 1+ metrics)

```js
{
  ...baseOption(theme),
  xAxis: { type: 'category', data: dates, boundaryGap: false,
           axisLine: { lineStyle: { color: axisColor } },
           axisLabel: { color: tickColor } },
  yAxis: { type: 'value',
           splitLine: { lineStyle: { color: gridColor } },
           axisLabel: { color: tickColor, formatter: numberFormat } },
  series: metrics.map((m, i) => ({
    name: m.label, type: 'line', data: m.values,
    smooth: false, symbol: 'circle', symbolSize: 0, showSymbol: false,
    lineStyle: { width: 2, color: CHART_COLOR_LIST[i] },
    emphasis: { focus: 'series' },
    areaStyle: metrics.length === 1 ? {
      color: { type: 'linear', x: 0, y: 0, x2: 0, y2: 1,
        colorStops: [
          { offset: 0, color: CHART_COLORS.blue + '33' },
          { offset: 1, color: CHART_COLORS.blue + '00' },
        ] },
    } : undefined,
  })),
}
```

### 2. Bar (categorical comparison)

```js
{
  ...baseOption(theme),
  xAxis: { type: 'category', data: categories, axisLabel: { interval: 0, rotate: categories.length > 6 ? -30 : 0 } },
  yAxis: { type: 'value', splitLine: { lineStyle: { color: gridColor } } },
  series: [{
    type: 'bar', data: values,
    itemStyle: { color: CHART_COLORS.blue, borderRadius: [4, 4, 0, 0] },
    barMaxWidth: 48,
    emphasis: { itemStyle: { color: CHART_COLORS.purple } },
  }],
}
```

### 3. Horizontal Bar (long category names, top-N)

```js
{
  ...baseOption(theme),
  grid: { top: 16, right: 24, bottom: 16, left: 120, containLabel: true },
  xAxis: { type: 'value' },
  yAxis: { type: 'category', data: categories, inverse: true,
           axisTick: { show: false } },
  series: [{ type: 'bar', data: values,
             itemStyle: { color: CHART_COLORS.blue, borderRadius: [0, 4, 4, 0] },
             label: { show: true, position: 'right', formatter: numberFormat } }],
}
```

### 4. Pie / Donut (composition, ≤6 categories)

```js
{
  ...baseOption(theme),
  series: [{
    type: 'pie', radius: ['55%', '80%'], center: ['50%', '50%'],
    avoidLabelOverlap: true, padAngle: 2,
    itemStyle: { borderRadius: 4, borderColor: bgColor, borderWidth: 2 },
    label: { show: true, formatter: '{b}\n{d}%' },
    data: items.map((it, i) => ({
      name: it.label, value: it.value,
      itemStyle: { color: CHART_COLOR_LIST[i % CHART_COLOR_LIST.length] },
    })),
  }],
}
```

For more than 6 categories, switch to horizontal bar.

### 5. Scatter (correlation between 2 numeric)

```js
{
  ...baseOption(theme),
  xAxis: { type: 'value', name: xLabel, nameGap: 28 },
  yAxis: { type: 'value', name: yLabel, nameGap: 36 },
  series: [{
    type: 'scatter', symbolSize: 8,
    itemStyle: { color: CHART_COLORS.blue, opacity: 0.6 },
    data: points,
  }],
}
```

### 6. Heatmap (2 categorical × 1 numeric)

```js
{
  ...baseOption(theme),
  tooltip: { position: 'top' },
  grid: { top: 16, right: 16, bottom: 56, left: 80 },
  xAxis: { type: 'category', data: xLabels, splitArea: { show: true } },
  yAxis: { type: 'category', data: yLabels, splitArea: { show: true } },
  visualMap: { min: 0, max: maxValue, calculable: true, orient: 'horizontal',
               left: 'center', bottom: 0, inRange: { color: SEQUENTIAL } },
  series: [{ type: 'heatmap', data: cells,
             label: { show: false },
             emphasis: { itemStyle: { shadowBlur: 8, shadowColor: 'rgba(0,0,0,0.4)' } } }],
}
```

### 7. Gauge (KPI vs goal)

```js
{
  ...baseOption(theme),
  series: [{
    type: 'gauge', startAngle: 200, endAngle: -20,
    min: 0, max: goal, splitNumber: 5,
    axisLine: { lineStyle: { width: 18,
      color: [[current/goal, CHART_COLORS.blue], [1, gridColor]] } },
    pointer: { show: false },
    progress: { show: false },
    axisTick: { show: false }, splitLine: { show: false },
    axisLabel: { show: false },
    detail: { valueAnimation: false, fontSize: 32, fontWeight: 'bold',
              formatter: numberFormat, offsetCenter: [0, '0%'] },
    data: [{ value: current }],
  }],
}
```

### 8. Funnel (stage progression)

```js
{
  ...baseOption(theme),
  series: [{
    type: 'funnel', left: 'center', top: 0, bottom: 0, width: '70%',
    sort: 'descending', gap: 2, label: { show: true, position: 'inside', formatter: '{b}: {c}' },
    itemStyle: { borderColor: bgColor, borderWidth: 2 },
    data: stages.map((s, i) => ({
      name: s.label, value: s.value,
      itemStyle: { color: CHART_COLOR_LIST[i] },
    })),
  }],
}
```

## Number Formatting

Define one helper used by every formatter:

```js
function numberFormat(v) {
  if (v == null) return '';
  if (Math.abs(v) >= 1e9) return (v / 1e9).toFixed(1) + 'B';
  if (Math.abs(v) >= 1e6) return (v / 1e6).toFixed(1) + 'M';
  if (Math.abs(v) >= 1e3) return (v / 1e3).toFixed(1) + 'k';
  if (Number.isInteger(v)) return v.toLocaleString();
  return v.toFixed(2);
}
```

For currency, prepend the currency symbol detected from the dataset (`$`, `R$`, `€`, etc.). For percentages, append `%`.

## Sparkline (for KPI cards)

Tiny line chart embedded in a KPI card:

```js
function sparkline(targetEl, values, colorKey = 'blue') {
  const chart = echarts.init(targetEl, null, { renderer: 'canvas' });
  chart.setOption({
    animation: false,
    grid: { top: 0, right: 0, bottom: 0, left: 0 },
    xAxis: { type: 'category', show: false, boundaryGap: false, data: values.map((_, i) => i) },
    yAxis: { type: 'value', show: false, scale: true },
    series: [{
      type: 'line', data: values, smooth: false, symbol: 'none',
      lineStyle: { width: 1.5, color: CHART_COLORS[colorKey] },
      areaStyle: { color: CHART_COLORS[colorKey] + '22' },
    }],
  });
  new ResizeObserver(() => chart.resize()).observe(targetEl);
  return chart;
}
```

## Anti-Patterns

- Do NOT enable `animation: true`. Animations break print and slow down dashboards.
- Do NOT use 3D charts ever.
- Do NOT use multiple Y-axes on a single chart unless metrics are in incomparable units.
- Do NOT use radar charts for more than 6 axes.
- Do NOT use word clouds.
