# Controls — Header, Filters, Per-Chart Actions

Every report includes the same set of controls. They are grouped in the header (global) and at chart level (local).

## Header Controls

Layout: a flex row with title on the left, controls on the right. Wraps to two rows on mobile.

```html
<header class="sticky top-0 z-30 bg-white/80 dark:bg-zinc-950/80 backdrop-blur border-b border-zinc-200 dark:border-zinc-800">
  <div class="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 py-3 sm:py-4
              flex flex-wrap items-center justify-between gap-3">
    <div class="min-w-0">
      <h1 class="text-lg sm:text-2xl font-bold text-zinc-900 dark:text-zinc-100 truncate">
        {{ reportTitle }}
      </h1>
      <p class="text-xs sm:text-sm text-zinc-500 dark:text-zinc-400 mt-0.5">
        {{ subtitle }}  ·  {{ sourceBadgesInline }}
      </p>
    </div>
    <div class="flex items-center gap-2 print:hidden">
      <!-- Filter trigger (mobile only) -->
      <button class="lg:hidden min-h-[44px] min-w-[44px] inline-flex items-center justify-center
                     rounded-lg border border-zinc-200 dark:border-zinc-800"
              aria-label="Open filters" @click="filterDrawerOpen = true">
        <svg class="w-5 h-5"><!-- filter icon --></svg>
      </button>
      <!-- Refresh -->
      <button class="min-h-[44px] min-w-[44px] inline-flex items-center justify-center
                     rounded-lg border border-zinc-200 dark:border-zinc-800"
              aria-label="Refresh" @click="refresh()">
        <svg class="w-5 h-5"><!-- refresh icon --></svg>
      </button>
      <!-- Print / PDF -->
      <button class="min-h-[44px] min-w-[44px] inline-flex items-center justify-center
                     rounded-lg border border-zinc-200 dark:border-zinc-800"
              aria-label="Print or save as PDF" @click="window.print()">
        <svg class="w-5 h-5"><!-- printer icon --></svg>
      </button>
      <!-- Dark mode toggle -->
      <button class="min-h-[44px] min-w-[44px] inline-flex items-center justify-center
                     rounded-lg border border-zinc-200 dark:border-zinc-800"
              aria-label="Toggle dark mode" @click="toggleTheme()">
        <svg class="w-5 h-5 dark:hidden"><!-- moon icon --></svg>
        <svg class="w-5 h-5 hidden dark:inline-block"><!-- sun icon --></svg>
      </button>
    </div>
  </div>
</header>
```

Use SVG icons inline (Lucide / Heroicons). Do not use icon fonts. Do not use emojis.

## Theme Toggle Implementation

```js
const THEME_KEY = 'prisma-reports-theme';
function applyTheme(theme) {
  document.documentElement.classList.toggle('dark', theme === 'dark');
  document.documentElement.dataset.theme = theme;
  document.documentElement.dispatchEvent(
    new CustomEvent('themechange', { detail: { theme } })
  );
  localStorage.setItem(THEME_KEY, theme);
}
function toggleTheme() {
  const current = document.documentElement.classList.contains('dark') ? 'dark' : 'light';
  applyTheme(current === 'dark' ? 'light' : 'dark');
}
// Init
(function () {
  const stored = localStorage.getItem(THEME_KEY);
  const prefers = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  applyTheme(stored || prefers);
})();
```

The `themechange` event lets ECharts instances re-style.

## Filter Bar

Sticky below the header, scrolling with the page on desktop. On mobile, lives in a bottom drawer.

```html
<div class="sticky top-[64px] z-20 bg-white dark:bg-zinc-950 border-b border-zinc-200 dark:border-zinc-800 print:hidden">
  <div class="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 py-3
              hidden lg:flex flex-wrap items-center gap-3">
    <!-- Date range picker -->
    <div class="flex items-center gap-1.5">
      <label class="text-xs text-zinc-500">Period</label>
      <select class="text-sm border-zinc-200 dark:border-zinc-800 rounded-md py-2 px-2"
              @change="applyDateFilter($event.target.value)">
        <option value="7d">Last 7 days</option>
        <option value="30d">Last 30 days</option>
        <option value="90d">Last quarter</option>
        <option value="ytd">Year to date</option>
        <option value="all" selected>All time</option>
      </select>
    </div>
    <!-- Category multi-select chips -->
    <template x-for="(facet, name) in facets">
      <div class="flex items-center gap-1.5">
        <label class="text-xs text-zinc-500" x-text="facet.label"></label>
        <div class="flex flex-wrap gap-1">
          <template x-for="value in facet.values">
            <button class="text-xs px-2 py-1.5 rounded-md border min-h-[32px]"
                    :class="facet.selected.includes(value)
                            ? 'bg-blue-600 border-blue-600 text-white'
                            : 'border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-300'"
                    @click="toggleFacet(name, value)" x-text="value"></button>
          </template>
        </div>
      </div>
    </template>
    <!-- Active filter count + clear -->
    <button class="ml-auto text-xs text-blue-600 dark:text-blue-400"
            x-show="activeFilterCount > 0" @click="clearFilters()">
      Clear all (<span x-text="activeFilterCount"></span>)
    </button>
  </div>
</div>
```

## Mobile Filter Drawer

```html
<div x-show="filterDrawerOpen" x-cloak
     class="fixed inset-0 z-50 lg:hidden"
     @keydown.escape.window="filterDrawerOpen = false">
  <div class="absolute inset-0 bg-black/40" @click="filterDrawerOpen = false"></div>
  <div class="absolute bottom-0 left-0 right-0 max-h-[80vh] overflow-y-auto
              bg-white dark:bg-zinc-950 rounded-t-2xl p-4">
    <div class="flex items-center justify-between mb-3">
      <h3 class="text-base font-semibold">Filters</h3>
      <button class="min-h-[44px] min-w-[44px]" @click="filterDrawerOpen = false"
              aria-label="Close filters">×</button>
    </div>
    <!-- Same filter content as desktop, stacked vertically -->
  </div>
</div>
```

## Per-Chart Actions

In the top-right of each chart card:

- **CSV download** — exports the chart's underlying data, respecting current filters.
- **Expand** — opens a modal with a larger version of the chart.
- **Info** — tooltip showing source, definition, unit, period (the same content as the legend).

```html
<figure class="card">
  <header class="flex items-start justify-between gap-2 mb-3">
    <div class="min-w-0">
      <h3 class="text-sm sm:text-base font-semibold truncate">{{ chart.title }}</h3>
      <p class="text-xs text-zinc-500 mt-0.5 truncate">{{ chart.subtitle }}</p>
    </div>
    <div class="flex items-center gap-1 print:hidden shrink-0">
      <button class="min-h-[36px] min-w-[36px] rounded-md hover:bg-zinc-100 dark:hover:bg-zinc-800"
              aria-label="Download CSV" @click="downloadCSV(chart)">
        <svg class="w-4 h-4 mx-auto"><!-- download icon --></svg>
      </button>
      <button class="min-h-[36px] min-w-[36px] rounded-md hover:bg-zinc-100 dark:hover:bg-zinc-800"
              aria-label="Expand chart" @click="expand(chart)">
        <svg class="w-4 h-4 mx-auto"><!-- expand icon --></svg>
      </button>
      <button class="min-h-[36px] min-w-[36px] rounded-md hover:bg-zinc-100 dark:hover:bg-zinc-800"
              aria-label="Chart info" @click="showInfo(chart)">
        <svg class="w-4 h-4 mx-auto"><!-- info icon --></svg>
      </button>
    </div>
  </header>
  <div class="echarts-target w-full h-64 sm:h-72 lg:h-80"></div>
  <figcaption class="mt-3 text-xs text-zinc-500 dark:text-zinc-400 leading-relaxed">
    <strong>Source:</strong> {{ source }} ·
    <strong>Definition:</strong> {{ definition }} ·
    <strong>Unit:</strong> {{ unit }} ·
    <strong>Period:</strong> {{ period }}
  </figcaption>
</figure>
```

## CSV Download Implementation

```js
function downloadCSV(chart) {
  const rows = chart.dataForExport(); // [{col1: ..., col2: ...}, ...]
  if (!rows.length) return;
  const headers = Object.keys(rows[0]);
  const escape = v => '"' + String(v ?? '').replace(/"/g, '""') + '"';
  const csv = [headers.join(','), ...rows.map(r => headers.map(h => escape(r[h])).join(','))].join('\n');
  const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = `${chart.slug}.csv`; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
```

## Glossary Modal

Always include a glossary that lists every metric and term. Triggered from a footer link or a "?" in the header.

```html
<dialog id="glossary" class="rounded-2xl p-0 max-w-lg w-[92vw] max-h-[80vh]">
  <div class="p-5 sm:p-6 overflow-y-auto">
    <div class="flex items-center justify-between mb-3">
      <h2 class="text-lg font-semibold">Glossary</h2>
      <button class="min-h-[44px] min-w-[44px]" onclick="this.closest('dialog').close()">×</button>
    </div>
    <dl class="space-y-3">
      <template x-for="entry in glossary">
        <div>
          <dt class="font-medium" x-text="entry.term"></dt>
          <dd class="text-sm text-zinc-600 dark:text-zinc-400 mt-1" x-text="entry.definition"></dd>
        </div>
      </template>
    </dl>
  </div>
</dialog>
```
