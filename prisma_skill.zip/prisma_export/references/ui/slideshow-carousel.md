# Slideshow Carousel — Mechanics

The slideshow is a simple, dependency-free carousel built with Alpine.js. No external carousel library.

## Markup

```html
<div class="slide-deck w-screen h-screen overflow-hidden relative bg-white dark:bg-zinc-950"
     x-data="slideshow()" x-init="init()"
     @keydown.window="onKey($event)">

  <!-- Progress bar -->
  <div class="absolute top-0 left-0 right-0 h-1 bg-zinc-200 dark:bg-zinc-800 z-30 print:hidden">
    <div class="h-full bg-blue-600 transition-all duration-200"
         :style="`width: ${((current+1)/total)*100}%`"></div>
  </div>

  <!-- Slides -->
  <template x-for="(slide, i) in slides" :key="i">
    <section class="slide absolute inset-0 transition-opacity duration-200"
             :class="i === current ? 'opacity-100 z-10' : 'opacity-0 z-0 pointer-events-none'"
             :data-slide-index="i">
      <!-- Slide content via dynamic include -->
    </section>
  </template>

  <!-- Click zones -->
  <button class="absolute left-0 top-0 w-1/4 h-full z-20 cursor-w-resize print:hidden
                 hidden sm:block" aria-label="Previous slide" @click="prev()"></button>
  <button class="absolute right-0 top-0 w-1/4 h-full z-20 cursor-e-resize print:hidden
                 hidden sm:block" aria-label="Next slide" @click="next()"></button>

  <!-- Bottom bar (mobile-friendly arrows + counter) -->
  <div class="absolute bottom-0 left-0 right-0 flex items-center justify-between
              p-3 sm:p-4 z-20 print:hidden">
    <button class="min-h-[44px] min-w-[44px] rounded-full bg-zinc-100 dark:bg-zinc-900
                   inline-flex items-center justify-center" aria-label="Previous"
            @click="prev()">‹</button>
    <div class="text-xs sm:text-sm text-zinc-500" x-text="`${current+1} / ${total}`"></div>
    <button class="min-h-[44px] min-w-[44px] rounded-full bg-zinc-100 dark:bg-zinc-900
                   inline-flex items-center justify-center" aria-label="Next"
            @click="next()">›</button>
  </div>

  <!-- Overview button -->
  <button class="absolute top-3 right-3 min-h-[44px] min-w-[44px] rounded-md
                 bg-zinc-100 dark:bg-zinc-900 z-20 print:hidden"
          aria-label="Overview" @click="overview = true">⊞</button>

  <!-- Overview grid -->
  <div x-show="overview" x-cloak
       class="absolute inset-0 z-40 bg-white dark:bg-zinc-950 overflow-y-auto p-4 sm:p-8">
    <div class="flex items-center justify-between mb-4">
      <h2 class="text-lg font-semibold">All slides</h2>
      <button class="min-h-[44px] min-w-[44px]" @click="overview = false">×</button>
    </div>
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
      <template x-for="(slide, i) in slides" :key="i">
        <button class="aspect-[16/9] rounded-lg border border-zinc-200 dark:border-zinc-800
                       overflow-hidden hover:border-blue-400 text-left p-3"
                @click="goto(i); overview = false;">
          <div class="text-[10px] text-zinc-500 mb-1" x-text="`${i+1}. ${slide.type}`"></div>
          <div class="text-sm font-medium" x-text="slide.title"></div>
        </button>
      </template>
    </div>
  </div>
</div>
```

## Alpine Component

```js
function slideshow() {
  return {
    current: 0,
    total: 0,
    overview: false,
    slides: [], // populated from JSON: [{type, title, ...}]
    init() {
      this.slides = JSON.parse(document.getElementById('slides-data').textContent);
      this.total = this.slides.length;
      // Deep link
      const m = location.hash.match(/^#slide-(\d+)$/);
      if (m) this.current = Math.max(0, Math.min(this.total - 1, parseInt(m[1]) - 1));
      // Touch swipe
      this.bindSwipe();
    },
    next() { if (this.current < this.total - 1) { this.current++; this.syncHash(); } },
    prev() { if (this.current > 0) { this.current--; this.syncHash(); } },
    goto(i) { this.current = i; this.syncHash(); },
    syncHash() { history.replaceState(null, '', `#slide-${this.current + 1}`); },
    onKey(e) {
      if (this.overview) {
        if (e.key === 'Escape') this.overview = false;
        return;
      }
      if (['ArrowRight', 'PageDown', ' '].includes(e.key)) { e.preventDefault(); this.next(); }
      if (['ArrowLeft', 'PageUp'].includes(e.key)) { e.preventDefault(); this.prev(); }
      if (e.key === 'Home') { e.preventDefault(); this.goto(0); }
      if (e.key === 'End') { e.preventDefault(); this.goto(this.total - 1); }
      if (e.key === 'o' || e.key === 'O') this.overview = true;
      if (e.key === '?' ) this.showHelp = !this.showHelp;
    },
    bindSwipe() {
      let startX = 0, startY = 0;
      this.$el.addEventListener('touchstart', e => {
        startX = e.touches[0].clientX; startY = e.touches[0].clientY;
      }, { passive: true });
      this.$el.addEventListener('touchend', e => {
        const dx = e.changedTouches[0].clientX - startX;
        const dy = e.changedTouches[0].clientY - startY;
        if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy)) {
          dx < 0 ? this.next() : this.prev();
        }
      }, { passive: true });
    },
  };
}
```

## Mobile Adaptation

Below 640px (`<sm`), the 16:9 frame becomes a vertical stack:

```css
@media (max-width: 639px) {
  .slide-deck { height: auto; min-height: 100vh; overflow: visible; }
  .slide {
    position: relative !important;
    opacity: 1 !important;
    z-index: auto !important;
    pointer-events: auto !important;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    justify-content: center;
    padding: 2rem 1.25rem;
    border-bottom: 1px solid rgb(228 228 231);
  }
  .slide [class*="text-["] { font-size: revert !important; } /* drop vw sizes */
  .slide-deck > .absolute.bottom-0 { display: none; }
  .slide-deck > .absolute.left-0,
  .slide-deck > .absolute.right-0 { display: none; }
}
```

In this mobile mode, the user simply scrolls. Keyboard / swipe nav still works on tablet and desktop.

## Slide Type Templates

Each slide type has a partial in `templates/partials/`. Examples:

- `slide-title.html` — hero text + optional bg image.
- `slide-big-stat.html` — one giant number + caption.
- `slide-headline-bullets.html` — `<h2>` + 3-5 bullets.
- `slide-chart.html` — title + ECharts target + takeaway.
- `slide-two-column.html` — left/right comparison.
- `slide-quote.html` — pull quote.
- `slide-section-divider.html` — colored full-bleed.
- `slide-closing.html` — recap.

## Help Overlay

```html
<div x-show="showHelp" x-cloak
     class="absolute inset-0 bg-black/70 z-50 flex items-center justify-center print:hidden"
     @click="showHelp = false">
  <div class="bg-white dark:bg-zinc-950 rounded-2xl p-6 max-w-md mx-4">
    <h3 class="text-lg font-semibold mb-3">Keyboard shortcuts</h3>
    <dl class="text-sm space-y-2">
      <div class="flex justify-between"><dt>Next slide</dt><dd><kbd>→</kbd> <kbd>Space</kbd></dd></div>
      <div class="flex justify-between"><dt>Previous slide</dt><dd><kbd>←</kbd></dd></div>
      <div class="flex justify-between"><dt>First / last</dt><dd><kbd>Home</kbd> <kbd>End</kbd></dd></div>
      <div class="flex justify-between"><dt>Overview</dt><dd><kbd>O</kbd></dd></div>
      <div class="flex justify-between"><dt>Close overlay</dt><dd><kbd>Esc</kbd></dd></div>
    </dl>
  </div>
</div>
```
