# File Sources — PDF / Excel / DOCX / CSV / TXT

The user can attach any of these. The parser normalizes them into the same JSON shape used by Databricks output, so the rest of the pipeline does not care about the origin.

## Supported Formats

| Extension | Library | Returns |
|---|---|---|
| `.csv`, `.tsv` | `pandas` | Tabular |
| `.xlsx`, `.xls` | `pandas` + `openpyxl` | Tabular (one entry per sheet) |
| `.pdf` | `pypdf` (text) + `pdfplumber` (tables) | Hybrid: extracted text + detected tables |
| `.docx` | `python-docx` | Hybrid: paragraphs + tables |
| `.txt`, `.md` | builtin | Free text |
| `.json` | builtin | Pass-through if shape matches; else free text |

If a dependency is missing, `scripts/file_parser.py` prints a single `pip install` line. Run it once, then retry.

## Permission Check

Before reading any attached file:

1. Check if the path matches `.gitignore` patterns. If yes, ask the user explicitly: "I need to read `<path>`. This file is in `.gitignore` and may contain sensitive data. Confirm to proceed?"
2. Check for common credential filenames: `.env`, `.env.*`, `credentials.*`, `secrets.*`, `*.key`, `*.pem`, `*.pfx`, `id_rsa*`. Ask permission for any of these regardless of `.gitignore`.

Do not skip this step. It is a hard rule.

## Normalized Output Shape

`scripts/file_parser.py` writes to `./prisma-output/<slug>/data/dataset.json`:

```json
{
  "source": {
    "type": "file",
    "format": "xlsx" | "pdf" | "docx" | "csv" | "txt" | "json",
    "filename": "Q4 sales.xlsx",
    "filesize_bytes": 184320,
    "parsed_at": "2026-05-05T10:42:00Z",
    "warnings": []
  },
  "tables": [
    {
      "name": "Sheet1" | "page-3-table-1",
      "columns": [
        { "name": "Region", "type": "string", "comment": null },
        { "name": "Revenue", "type": "number", "comment": null }
      ],
      "rows": [
        { "Region": "BR-SP", "Revenue": 12340.5 },
        ...
      ]
    }
  ],
  "text": "Concatenated free-form text extracted from the document, in reading order."
}
```

The downstream analyzer treats `tables[*]` as candidate datasets and `text` as a corpus to mine for named numbers (e.g. "revenue grew 12% YoY").

## Format-Specific Notes

### CSV / TSV

- Auto-detect delimiter via `csv.Sniffer`. Fallback to `,` then `\t` then `;`.
- Auto-detect encoding via `chardet`. Fallback to `utf-8` then `latin-1`.
- Trim whitespace from headers.
- Coerce numeric columns; keep originals if coercion fails for >5% of rows.
- Date columns: try `dateutil.parser` on the first 50 non-null cells. If >90% parse, mark column as temporal.

### Excel

- Read every sheet. Skip sheets whose first 10 rows are entirely empty.
- Detect header row: first row where >50% of cells are non-numeric strings.
- For sheets with merged cells in the header, unmerge in memory and forward-fill the labels.
- Drop sheets named `Sheet2`, `Sheet3`, ... if they are empty.

### PDF

- Extract text with `pypdf` first. If text density is < 50 chars/page, the PDF is likely scanned — emit a warning in `source.warnings` and recommend OCR.
- Run `pdfplumber` to detect tables. Each detected table becomes one entry in `tables[]` named `page-<N>-table-<M>`.
- Strip running headers/footers (lines that repeat on >50% of pages).
- Preserve paragraph order in `text`.

### DOCX

- Iterate `document.element.body` to keep the original order of paragraphs and tables.
- Each table becomes one entry in `tables[]` named `table-<N>`.
- Concatenate paragraph text into `text`, separated by `\n\n`.
- Skip text inside `<w:trackChanges>` deletions.

### TXT / MD

- Read as UTF-8.
- Whole content goes into `text`.
- `tables[]` is empty.

### JSON

- If the top level is an array of flat objects with consistent keys, treat as `tables[0]`.
- If the top level is an object with `{ columns: [], rows: [] }`, pass through.
- Otherwise, stringify and put into `text`.

## Multi-File Inputs

If the user attaches more than one file, parse each into its own `dataset.json` under `data/files/<index>-<filename>.json`, then write a top-level `data/dataset.json` that merges:

- `source.type = "multi-file"`, `source.files = [...]`
- `tables` = concatenation, with table names prefixed by source filename
- `text` = concatenation, separated by `\n\n--- FROM <filename> ---\n\n`

The analyzer will treat each table as a candidate dataset and try to relate them by shared column names.

## Sanity Caps

- Max file size: 50 MB. If exceeded, ask the user how to proceed (sample, split, skip).
- Max rows per table: 100000. If exceeded, take a uniform random sample of 100000 and add a footnote.
- Max free-text length: 5 MB. If exceeded, truncate and warn.
