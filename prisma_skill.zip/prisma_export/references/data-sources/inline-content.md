# Inline Content — Pasted Notes and Free Text

When the user pastes text directly (notes, meeting summary, email thread) instead of attaching a file, follow this lightweight path.

## Capture

1. Save the pasted text verbatim to `./prisma-output/<slug>/data/input.txt`. Preserve original whitespace and line breaks.
2. Invoke the file parser the same way you would for a `.txt` attachment: `python scripts/file_parser.py --input ./prisma-output/<slug>/data/input.txt --output ./prisma-output/<slug>/data/dataset.json`.

## Mining the Text for Numbers

The analyzer applies these regex patterns to extract named numbers:

| Pattern | Captures | Example |
|---|---|---|
| `(\d[\d,.]*)\s*%` | Percentages | `12.5%`, `12,5%` |
| `(?:USD|US\$|\$|R\$|€|£)\s*(\d[\d,.]*)` | Currencies | `$12,340`, `R$ 1.234` |
| `(\d[\d,.]*)\s*(million|billion|k|M|B|mil|milhões|bi)` | Magnitudes | `12 million`, `3.4B` |
| `\b(?:Q[1-4]|[Hh][12])\s*\d{2,4}\b` | Periods | `Q4 2025`, `H1 24` |
| `\b\d{4}\b(?!\s*(?:hours|usuários))` | Years | `2024`, `2025` |

For each match, the analyzer records:
- The captured value (parsed to float when possible).
- The 60-character window of context around the match.
- The line number in the input.

These become "named facts" used in the narrative report. Each is shown with the verbatim sentence as the legend (`Source: pasted text, line 14`).

## Structuring Free Text

If the text contains explicit headings (Markdown-style `#`, `##`, or numbered lists like `1.`, `2.`) the analyzer uses them as section breaks. Each section becomes a separate narrative card in the report, in original order.

If there are no headings, the analyzer treats paragraphs as units and groups them by topic via simple keyword clustering (TF-IDF on noun phrases). This is best-effort. If the result looks weak, the report falls back to a single "Notes" section displaying the text in a typographically polished layout.

## Detecting Embedded Tables

The analyzer detects pseudo-tables in plain text:

- **Pipe-style:** `| Col A | Col B |` followed by `|---|---|` (Markdown).
- **Aligned columns:** Two or more lines where words align at the same column positions and there is a separator row of dashes.

Detected tables are converted into `tables[]` entries with auto-named columns (`Col A`, `Col B`) if no header row is identifiable.

## Quality Gate

If the input text is shorter than 200 characters and contains no extractable numbers and no tables, do not generate a chart-heavy report. Generate a Narrative Report with the user's text rendered as the body and a single "Key takeaways" card listing 1–3 sentences distilled from the text.

## Privacy

Never echo the user's pasted text to chat. Reference it only by line number in your reasoning. The text appears verbatim only inside the rendered HTML report and the local `input.txt`.
