# Databricks — Read-Only Access

This file is the single source of truth for any warehouse interaction in this skill. Read it before calling `scripts/databricks_query.py`.

## Hard Rules

1. **Read-only.** Reject any SQL containing `INSERT`, `UPDATE`, `DELETE`, `MERGE`, `DROP`, `TRUNCATE`, `ALTER`, `CREATE`, `REPLACE`, `GRANT`, `REVOKE`, `COPY`, `LOAD`, `UNLOAD`, `CALL`, or `EXECUTE` (case-insensitive, word-boundary regex). The check lives in `scripts/databricks_query.py::is_read_only`. Do not bypass it.
2. **No string interpolation of free-form user text into SQL.** Validate identifiers against an allowlist before concatenating. Warehouses generally reject parameterized queries, so safety must come from validation.
3. **Credentials only from environment variables.** Never write them to logs, JSON outputs, or generated HTML.
4. **Default `LIMIT 10000` on table-mode queries.** If the user explicitly asks for more, cap at 100000 and warn in the report footer.

## Connector Auto-Detection

The script tries the following imports in order and uses the first that succeeds:

| Order | Import | Package |
|---|---|---|
| 1 | `from databricks import sql` | `databricks-sql-connector` |
| 2 | `from databricks.sdk import WorkspaceClient` + `StatementExecutionAPI` | `databricks-sdk` |
| 3 | `databricks` binary on PATH | Databricks CLI |

If none is available, the script prints exactly:

```
ERROR: No Databricks client found.
Install one of:
  pip install databricks-sql-connector
  pip install databricks-sdk
  brew install databricks
```

When you see this, run the suggested `pip install` once via `Bash` and retry. Do not try to write your own client.

## Required Environment Variables

| Variable | Required when | Example |
|---|---|---|
| `DATABRICKS_HOST` | always | `https://adb-1234567890.12.azuredatabricks.net` |
| `DATABRICKS_HTTP_PATH` | sql-connector, CLI | `/sql/1.0/warehouses/abcd1234efgh5678` |
| `DATABRICKS_TOKEN` | always (PAT) | `dapi...` |
| `DATABRICKS_CATALOG` | optional | `main` |
| `DATABRICKS_SCHEMA` | optional | `default` |

If `DATABRICKS_HOST` or `DATABRICKS_TOKEN` is missing, ask the user to set them once. Do not paste values back to the user.

## Two Modes

### Mode A — Table access (generic report)

User says: "use table `sales.q4_orders`" with no SELECT clause.

Execute:

```sql
SELECT * FROM `<catalog>`.`<schema>`.`<table>` LIMIT 10000
```

Validate `<catalog>`, `<schema>`, `<table>` against the regex `^[A-Za-z_][A-Za-z0-9_]*$`. Reject anything else.

Then describe the schema:

```sql
SELECT column_name, data_type, comment
FROM `<catalog>`.information_schema.columns
WHERE table_schema = '<schema>' AND table_name = '<table>'
ORDER BY ordinal_position
```

Use the schema info to label columns in the report and to pick chart types in `references/analysis/insight-extraction.md`.

### Mode B — Query execution

User provides a `SELECT`. The script:

1. Strips trailing semicolons.
2. Runs `is_read_only()` regex check.
3. Wraps with `LIMIT 10000` if no `LIMIT` is present and the query is a single statement.
4. Executes.

If the user query already contains `LIMIT N` with `N > 100000`, override to 100000 and add a footnote in the report: `Note: result capped at 100,000 rows.`

## Databricks SQL Dialect Notes

- Identifier quoting: use backticks. `` `catalog`.`schema`.`table` `` or `` `catalog.schema.table` `` (one piece) both work; prefer the three-part form.
- `INFORMATION_SCHEMA` lives under each catalog: `<catalog>.information_schema.{tables,columns,views}`.
- Sampling: `SELECT * FROM \`c.s.t\` TABLESAMPLE (1000 ROWS)` is preferred over `LIMIT` for representative samples on large tables.
- Date functions: `date_trunc('month', ts)`, `date_add(d, 7)`, `current_timestamp()`.
- Timestamps return as ISO 8601 strings; the parser preserves them and the analyzer detects them.

## Schema Exploration for Unknown Tables

When the user names a table you have not seen and it has more than 30 columns, run schema exploration first:

```sql
-- List columns with type and comment
SELECT column_name, data_type, comment
FROM `<catalog>`.information_schema.columns
WHERE table_schema = '<schema>' AND table_name = '<table>'
ORDER BY ordinal_position;

-- Sample 5 rows to detect actual content shape
SELECT * FROM `<catalog>.<schema>.<table>` TABLESAMPLE (5 ROWS);

-- Row count for context
SELECT COUNT(*) AS row_count FROM `<catalog>.<schema>.<table>`;
```

Use the comments column when present — it often contains the human-readable definition you should put into the chart legend.

## Output Shape

`scripts/databricks_query.py` writes to `./prisma-output/<slug>/data/dataset.json`:

```json
{
  "source": {
    "type": "databricks",
    "mode": "table" | "query",
    "table": "catalog.schema.table" | null,
    "query": "<original SQL with sensitive parts redacted>",
    "row_count": 9421,
    "fetched_at": "2026-05-05T10:42:00Z",
    "row_cap_applied": false
  },
  "columns": [
    { "name": "order_date", "type": "timestamp", "comment": "Order placement timestamp" },
    { "name": "region", "type": "string", "comment": null },
    { "name": "amount", "type": "double", "comment": "Order total in USD" }
  ],
  "rows": [
    { "order_date": "2025-01-03T...", "region": "BR-SP", "amount": 432.10 },
    ...
  ]
}
```

The `rows` array is the authoritative dataset for analysis and rendering. Never re-query inside the analyzer.

## Failure Modes

| Symptom | Cause | Action |
|---|---|---|
| `ImportError: databricks` | No connector installed | Run `pip install databricks-sql-connector`, retry |
| `Forbidden` / 403 | Token lacks `SELECT` on table | Ask user to grant `USE SCHEMA` and `SELECT` on the specific object |
| `THRIFT_RESULT_TIMEOUT` | Query too slow | Add `LIMIT` or aggregate; do not retry blindly |
| `SQL_FEATURE_NOT_SUPPORTED` for params | User passed bind variables | Move to allowlist validation; do not pass `params` |
| Empty `rows` | Filter too narrow | Show "no data for the selected period" page in the report; do not abort the workflow |
