# Storytelling — From Insights to Narrative

The mechanical analysis tells you WHAT changed. Storytelling tells the audience WHY they should care and WHAT to do.

## The Pyramid Principle

Lead with the answer. Then evidence. Then context. Never bury the headline.

```
[ Answer / recommendation ]
       ↓
[ 2-4 supporting facts ]
       ↓
[ Background context ]
       ↓
[ Methodology / caveats ]
```

The reader should be able to stop after the first sentence of the executive summary and still know what to do.

## Section Pattern: Context → Evidence → Implication

Every report section follows this three-beat structure:

1. **Context (1 sentence)** — set the scene. What is the metric? What was happening before?
2. **Evidence (1 visual + 1-2 sentences)** — show the data with one chart, then state the fact in plain language.
3. **Implication (1-3 sentences)** — what this means for the reader's decisions.

Example:

> **Mobile orders overtook web for the first time in 2025**
>
> *Context:* Through 2024, web orders consistently led mobile by 15-25 percentage points. Mobile traffic grew steadily but conversion lagged.
>
> *[Chart: stacked area of monthly order share by channel]*
>
> *Evidence:* In November 2025, mobile reached 51% of orders, up from 38% in May.
>
> *Implication:* Mobile is no longer a secondary channel. Marketing budget allocation, page-load targets, and design priority should reflect this. Web-first feature work is now the exception, not the default.

## Connecting Sections

Each section should reference the previous one when the topic naturally chains. Use transitional phrases:

- "Building on the regional trend above..."
- "This raises a question about..."
- "The same pattern shows up in..."

This is what turns a list of charts into a story.

## Headlines That Work

A working headline answers: **what changed, by how much, and where**.

| Weak | Strong |
|---|---|
| "Q4 results" | "Q4 revenue up 12%, driven by BR-SP" |
| "Channel mix" | "Mobile passed web in November (51% of orders)" |
| "Customer breakdown" | "Top 3 regions hold 78% of orders; concentration up from 71% in Q3" |
| "Trends" | "Average order value declined for 6 straight weeks" |

Avoid noun-only titles. Avoid clever wordplay. Be a journalist, not a poet.

## The "So What?" Test

After every paragraph, ask: "So what?". If the answer is not clear, either rewrite to make the implication explicit or delete the paragraph.

## Recommendations Block

Close the report with a numbered list of recommendations. Each recommendation must be:

- **Specific** — name a system, team, or product.
- **Actionable** — start with a verb (Reduce, Investigate, Reallocate, Pause, Continue).
- **Time-bound** — include a horizon (this week, this quarter, before next launch).

Example:

> **Recommendations**
>
> 1. **Reallocate 30% of acquisition budget to mobile** within the next two weeks. Current allocation reflects 2024 channel mix and is now off by 13 points.
> 2. **Audit the BR-SP region's logistics SLA** before December. The region drives 30% of revenue and a 1-day SLA slip there outweighs improvements anywhere else.
> 3. **Investigate the November 14 spike in returns** (3.2x baseline). Confirm whether it is a single product defect or a category-wide issue.

## Caveats and Limits

The methodology section is the last section. It contains:

- Source(s) and read time (e.g. "Databricks `sales.q4_orders`, fetched 2026-05-05 10:42 UTC").
- Filters applied (e.g. "Orders with `status = 'completed'`; excluded test accounts").
- Time range covered.
- Sample size and any sampling caveats.
- Known data quality issues (high null rates, mixed types, suspect date ranges).
- A list of metrics with definitions (also linked from the glossary).

Be honest about limits. A report that hides its caveats loses credibility forever.

## Tone

- **Direct.** No hedging without cause. "Revenue grew 12%" not "Revenue may have shown some growth".
- **Concrete.** Replace "increased" with the specific number or direction.
- **Reader-first.** Use second person sparingly ("Your team should"). Mostly write in third person about the data.
- **No filler.** Cut: "It is important to note that", "Interestingly", "As we can see", "Going forward".

## Length

| Report type | Word count target |
|---|---|
| Dashboard (text portions) | 200-400 words total |
| Narrative Report | 800-1500 words |
| Explorer (intro only) | 100-200 words |
| Slideshow (per slide caption) | 5-25 words |

Longer is not better. Cut until every sentence earns its place.
