# Data Legends — Mandatory Footer for Every Visual

Every KPI card and every chart MUST display a legend identifying where the data comes from, what it measures, in what unit, and over what period. No exceptions.

## Required Fields

| Field | Description | Example |
|---|---|---|
| **Source** | The origin of the data | `Databricks: sales.q4_orders` / `PDF: Q4-report.pdf, page 7` / `Pasted notes, line 23` |
| **Definition** | What the metric measures, in plain language | `Sum of order totals after discounts and before tax` |
| **Unit** | Currency, count, percentage, ratio | `USD`, `orders`, `percentage points`, `seconds` |
| **Period** | Time window the data covers | `Jan 1 – Mar 31, 2025` |

Optional but encouraged:

| Field | Description |
|---|---|
| **Filters applied** | Any filters that change the result vs raw data | `status = 'completed', excluded test accounts` |
| **Comparison baseline** | When the chart shows a delta | `vs Q3 2024 (Oct 1 – Dec 31)` |
| **Sample note** | When data is sampled | `Random sample of 100,000 of 4.2M rows` |

## Legend Markup (Charts)

Inside the `<figure>`:

```html
<figcaption class="mt-3 text-xs text-zinc-500 dark:text-zinc-400 leading-relaxed">
  <strong class="text-zinc-700 dark:text-zinc-300">Source:</strong> Databricks · sales.q4_orders ·
  <strong class="text-zinc-700 dark:text-zinc-300">Definition:</strong> Sum of order totals after discounts ·
  <strong class="text-zinc-700 dark:text-zinc-300">Unit:</strong> USD ·
  <strong class="text-zinc-700 dark:text-zinc-300">Period:</strong> Jan 1 – Mar 31, 2025
</figcaption>
```

On mobile, the legend wraps naturally. Do not truncate it. The legend is not optional and not collapsible.

## Legend Markup (KPI Cards)

KPI cards have less space, so the legend appears as an info icon (`ⓘ`) that opens a tooltip / popover:

```html
<article class="card relative">
  <button class="absolute top-3 right-3 min-h-[32px] min-w-[32px] text-zinc-400
                 hover:text-zinc-600" aria-label="What is this?"
          @click="$dispatch('open-info', kpi)">
    <svg class="w-4 h-4 mx-auto"><!-- info icon --></svg>
  </button>
  <div class="text-xs text-zinc-500 dark:text-zinc-400">{{ kpi.label }}</div>
  <div class="text-3xl sm:text-4xl font-bold mt-1">{{ kpi.formattedValue }}</div>
  <div class="text-xs mt-1" :class="kpi.delta >= 0 ? 'text-green-600' : 'text-red-600'">
    {{ kpi.deltaArrow }} {{ kpi.deltaText }}
  </div>
  <div class="mt-2"><div class="sparkline h-5 w-full"></div></div>
  <!-- Hidden machine-readable legend, surfaced via tooltip / dialog -->
  <template x-data-legend>
    <span data-source="{{ source }}"
          data-definition="{{ definition }}"
          data-unit="{{ unit }}"
          data-period="{{ period }}"></span>
  </template>
</article>
```

The `open-info` event opens a small dialog with the same four fields.

## Source Badge Format

Across the report header, the active sources are shown as compact badges:

```html
<div class="flex flex-wrap items-center gap-1.5">
  {% for source in sources %}
  <span class="inline-flex items-center gap-1 px-2 py-1 rounded-md
               bg-zinc-100 dark:bg-zinc-900 text-xs text-zinc-700 dark:text-zinc-300">
    <svg class="w-3 h-3"><!-- source-type icon --></svg>
    {{ source.label }}
  </span>
  {% endfor %}
</div>
```

| Source type | Icon | Label format |
|---|---|---|
| Databricks | small lightning bolt | `Databricks: catalog.schema.table` |
| SQL query | terminal icon | `SQL: <first 40 chars of query>...` |
| Excel | grid icon | `Excel: <filename>` |
| PDF | document icon | `PDF: <filename>` |
| DOCX | document icon | `DOCX: <filename>` |
| CSV | grid icon | `CSV: <filename>` |
| Pasted text | quote icon | `Notes: <N> lines` |

## Time Period Wording

Use unambiguous formats. Always include the year.

| Bad | Good |
|---|---|
| "Last 30 days" | "Apr 5 – May 5, 2026" |
| "Q4" | "Q4 2025 (Oct 1 – Dec 31)" |
| "YTD" | "Year to date (Jan 1 – May 5, 2026)" |
| "All time" | "All available data (Jan 2023 – May 2026)" |

If the chart filter changes the period dynamically, recompute the period text live.

## Definition Wording

Definitions must be plain language. Avoid SQL fragments, avoid abbreviations without expansion.

| Bad | Good |
|---|---|
| `SUM(amount)` | "Sum of order totals" |
| "AOV" | "Average order value (total revenue divided by number of orders)" |
| "DAU" | "Daily active users (users who opened the app at least once that day)" |
| "MoM growth" | "Growth compared to the previous calendar month" |

## Currency / Unit Display

- Format currency with the symbol and locale: `R$ 12.345,67`, `$12,345.67`, `€ 12 345,67`.
- Format counts with thousand separators: `12,345 orders`.
- Format percentages with one decimal when below 10, no decimals above: `8.4%`, `42%`.
- Format durations with the largest unit that fits: `2.3 seconds`, `4 minutes`, `1.2 hours`.

## Validation

`scripts/validate_report.py` parses the rendered HTML and confirms:

- Every `<figure>` contains a `<figcaption>` with all four required fields.
- Every KPI card has either an inline legend or a `data-source` attribute set.
- All source badges resolve to one of the documented types.

If validation fails, fix the report. Do not ship without legends.
