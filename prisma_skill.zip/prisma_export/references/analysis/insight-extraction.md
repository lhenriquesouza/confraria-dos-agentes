# Insight Extraction — From Data to Headlines

This file describes how to turn the analyzer output into the report content. The analyzer produces mechanical findings; you produce the headlines.

## Column Type Detection (recap)

The analyzer classifies each column as:

- **Identifier** — high-cardinality string column with unique values. Excluded from charts.
- **Categorical** — string with low-to-mid cardinality (≤ 200 unique values). Used as dimensions.
- **Numeric** — int / float. Used as metrics.
- **Temporal** — datetime-parseable. Used as time axis.
- **Free text** — long strings, low cardinality, mostly distinct. Mined for keywords only.

## Chart Picker (Dimension × Metric Matrix)

| Dimensions | Metrics | Recommended chart |
|---|---|---|
| 1 temporal | 1 numeric | Line chart |
| 1 temporal | 2-5 numeric | Multi-line |
| 1 temporal | 1 numeric × 1 categorical (split) | Stacked area |
| 1 categorical | 1 numeric | Horizontal bar (top-N) |
| 1 categorical | 2 numeric | Grouped bar |
| 2 categorical | 1 numeric | Heatmap |
| 0 dimensions | 1 numeric distribution | Histogram |
| 1 numeric | 1 numeric | Scatter |
| 1 categorical, parts of 100% | 1 numeric | Donut (≤6) or stacked bar (>6) |
| funnel-shaped categorical | 1 numeric | Funnel |
| current vs goal | 1 numeric | Gauge |

If the data shape supports multiple options, prefer the one that puts the most important variable on the longest axis (typically X for time, Y for category).

## KPI Selection Rule

Pick 4–6 KPIs for the dashboard / executive summary. A KPI is a single number that answers an executive question. Selection priorities:

1. **Headline metric** — the one number the audience cares about most (e.g. revenue, active users, NPS).
2. **Comparison delta** — the same metric vs the previous period.
3. **Top contributor** — the dimension value with the largest share (e.g. top region, top product).
4. **Outlier or risk** — the most negative deviation worth flagging.
5. **Volume context** — total rows, time span, or coverage.
6. **Goal vs actual** — when a goal exists in the data or in the user's prompt.

Each KPI gets a sparkline if its underlying series has at least 6 data points.

## Insight Candidate Scoring

The analyzer ranks candidate insights by:

- **Magnitude** — absolute size of the change or value (normalized 0..1).
- **Surprise** — z-score vs the rolling baseline.
- **Coverage** — share of total volume affected.
- **Actionability** — whether the dimension is something the audience can act on.

Pick the top 5–8 candidates for a Dashboard, top 3–5 for a Narrative Report, top 7–12 for a Slideshow.

## Headlines Style

Each insight becomes a sentence-case headline that states the finding, not the topic.

| Bad | Good |
|---|---|
| "Revenue trends" | "Revenue grew 12% in Q4, led by the BR-SP region" |
| "Customer regions" | "Three regions account for 78% of orders" |
| "Performance" | "Average order value fell to R$84 in November" |
| "Product breakdown" | "Mobile orders overtook web for the first time in 2025" |

A headline must contain at least one number when one exists in the underlying data.

## Comparisons

Always show comparison context where possible:

- vs previous period (`vs Q3`, `vs same week last year`).
- vs benchmark (if user provided one).
- vs target (if user provided one).
- vs other categories (rank position).

Show direction and magnitude together: `▲ 12% vs Q3` (arrow + percent + baseline label).

## Time-Series Tricks

- Always include a **rolling average** line on noisy daily / hourly series. 7-day rolling for daily series, 4-week rolling for weekly.
- Mark **anomalies** (z-score > 3) with a labeled annotation.
- For time series with a clear seasonal pattern, add a **same-period last year** ghost line in light gray.

## Composition Tricks

- Cap categorical breakdowns at 8 slices. Group the rest into "Other" using `slate` color.
- Always show absolute value AND percentage in tooltips.
- Sort categories descending by value, except when there is a natural order (e.g. days of week).

## Correlation Tricks

- Only report correlations with `|r| ≥ 0.3` and with at least 30 data points.
- Always pair the correlation with a scatter chart so the audience can see it.
- Caveat in the legend: `Note: correlation does not imply causation`.

## Outlier Tricks

- Flag the top 5 most extreme rows by the IQR rule.
- Show them in a small "Watch list" card with the row's key fields.
- In a chart, render outliers as larger / brighter markers.

## When the Data is Thin

If the dataset has fewer than 30 rows or only one numeric column:

- Drop the dashboard layout. Use the Narrative Report instead.
- Replace the chart matrix with one or two well-chosen visuals.
- Focus the narrative on the top 1–3 facts.
- Add a footnote: "Based on a small dataset (N=X). Treat conclusions as directional."

## When the Data is Dirty

The analyzer flags:
- Columns with > 30% nulls.
- Columns with mixed types (e.g. numeric strings + actual numbers).
- Date columns with future dates that look like data entry errors.

For each flag, add a "Data quality" callout in the methodology section. Do not silently filter; explain what was excluded.
