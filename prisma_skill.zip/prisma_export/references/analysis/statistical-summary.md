# Statistical Summary — Pandas Operations

The analyzer (`scripts/statistical_analysis.py`) runs these pandas operations and exposes them in `analysis.json`. Use them as raw material; do not re-implement.

## Per-Column Statistics

### Numeric columns

```python
df[col].describe(percentiles=[.1, .25, .5, .75, .9, .95, .99]).to_dict()
df[col].skew()       # > 1 means right-skewed; consider log scale
df[col].kurt()       # > 3 means heavy tails
df[col].isna().mean() # null rate
```

Output per numeric column:

```json
{
  "type": "numeric",
  "count": 9421,
  "null_rate": 0.012,
  "mean": 142.50,
  "median": 84.00,
  "std": 211.30,
  "min": 0,
  "max": 9999,
  "p10": 12, "p25": 38, "p50": 84, "p75": 180, "p90": 410, "p95": 720, "p99": 2400,
  "skew": 2.4,
  "kurt": 8.7,
  "outlier_count": 142,    // by IQR rule
  "outlier_threshold_low": -200,
  "outlier_threshold_high": 480
}
```

### Categorical columns

```python
vc = df[col].value_counts(dropna=False)
top = vc.head(10).to_dict()
total = vc.sum()
top_share = vc.head(10).sum() / total
```

Output:

```json
{
  "type": "categorical",
  "count": 9421,
  "unique": 18,
  "null_rate": 0.0,
  "top": [
    { "value": "BR-SP", "count": 2840, "share": 0.302 },
    { "value": "BR-RJ", "count": 1210, "share": 0.128 },
    ...
  ],
  "top10_share": 0.94,
  "long_tail_count": 8     // categories beyond top 10
}
```

### Temporal columns

```python
df[col] = pd.to_datetime(df[col], errors='coerce')
out = {
  "min": df[col].min().isoformat(),
  "max": df[col].max().isoformat(),
  "span_days": (df[col].max() - df[col].min()).days,
  "missing_periods": detect_gaps(df[col])  # gaps > median spacing
}
```

## Aggregations

For each (categorical, numeric) pair:

```python
g = df.groupby(cat)[metric].agg(['sum', 'mean', 'median', 'count']).reset_index()
g = g.sort_values('sum', ascending=False)
```

The top 8 rows go into the report; the rest collapse into "Other".

## Time Bucketing

For each (temporal, numeric) pair, bucket by:

- **hour** if total span < 3 days
- **day** if total span < 90 days
- **week** if total span < 540 days
- **month** otherwise

```python
df['bucket'] = df[ts_col].dt.to_period('D').dt.to_timestamp()
ts = df.groupby('bucket')[metric].sum().reset_index()
ts['rolling7'] = ts[metric].rolling(7, min_periods=1).mean()
```

## Period-Over-Period

Compute `current_period_total` and `previous_period_total`. The current period is the last `N` buckets where `N` is half the total range. Delta = `(current - previous) / previous`.

## Correlations

```python
numeric_cols = df.select_dtypes(include='number').columns.tolist()
corr = df[numeric_cols].corr(method='pearson').stack()
corr = corr[(corr.index.get_level_values(0) < corr.index.get_level_values(1))]
strong = corr[corr.abs() >= 0.3].sort_values(key=lambda s: s.abs(), ascending=False)
```

Report only pairs with `|r| ≥ 0.3` and at least 30 paired observations.

## Outliers (IQR)

```python
q1, q3 = df[col].quantile([.25, .75])
iqr = q3 - q1
low = q1 - 1.5 * iqr
high = q3 + 1.5 * iqr
outliers = df[(df[col] < low) | (df[col] > high)]
```

Report the 10 most extreme rows by absolute distance from the median.

## Insight Candidate Scoring

```python
score = magnitude * surprise * coverage
```

- `magnitude` = `|delta|` normalized to 0..1 across all candidates.
- `surprise` = z-score of the value vs the historical baseline (rolling mean ± 2 std), capped at 3, normalized to 0..1.
- `coverage` = share of total volume the candidate represents (rows or sum), 0..1.

Sort descending. The top K depends on the report type (5–8 dashboard, 3–5 narrative, 7–12 slideshow).

## Output File

`analysis.json` shape:

```json
{
  "summary": {
    "row_count": 9421,
    "column_count": 14,
    "time_span_days": 92,
    "primary_metric": "amount",
    "primary_dimension": "region",
    "primary_temporal": "order_date"
  },
  "columns": { "<col_name>": { ... } },
  "aggregations": {
    "by_<cat>_<metric>": [ { "value": "...", "sum": 12345, ... }, ... ]
  },
  "time_series": {
    "<temporal>_<metric>": {
      "bucket": "day",
      "points": [ { "ts": "2025-01-01", "value": 1234, "rolling7": 1100 }, ... ]
    }
  },
  "correlations": [ { "x": "amount", "y": "discount", "r": -0.42, "n": 9421 }, ... ],
  "outliers": [ { "row_index": 4218, "column": "amount", "value": 9999, "z": 4.7 }, ... ],
  "insights": [
    { "rank": 1, "score": 0.92, "headline": "Revenue grew 12% in Q4...", "type": "trend",
      "evidence": { "metric": "amount", "current": 2400000, "previous": 2140000 } },
    ...
  ]
}
```
