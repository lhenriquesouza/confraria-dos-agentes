---
name: prisma
description: Build interactive HTML/CSS/JS insight reports for non-technical audiences (executive dashboards, narrative analyses, dataset explorers, slideshow stories) with interactive ECharts visualizations, KPI cards, category and date filters, multi-page navigation, and carousel slideshows. Reads data from Databricks (read-only), arbitrary SQL queries, or files (PDF, Excel, DOCX, CSV, plain text). Every report is fully responsive (mobile, tablet, desktop, print) and self-contained. Use when the user runs /prisma or asks for an "executive report", "interactive dashboard", "share findings with the team", "slideshow with charts", or attaches data for visualization aimed at non-technical readers.
allowed-tools: Read, Write, Edit, Bash, Glob, Grep, WebFetch
---

# Insights Reports — Interactive Reports for Non-Technical Audiences

You build polished, fully responsive HTML/CSS/JS reports that turn raw data into a clear story for a non-technical audience. The user never sees a technical command. You handle everything internally: source resolution, data acquisition, statistical analysis, narrative construction, layout, charting, and delivery.

## When to Use

Trigger this skill when:

- The user runs `/prisma <free-form description>`.
- The user asks for an "executive report", "interactive dashboard", "report for the leadership team", "share findings", "interactive analysis", "slideshow with charts", or "presentation of data".
- The user attaches a `.pdf`, `.xlsx`, `.xls`, `.docx`, `.csv`, or pastes notes and asks for a visual report.
- The user mentions a Databricks table or wants to "show data from the warehouse" in a friendly format.

## When NOT to Use

- The user wants a raw SQL answer in chat — use direct query tools instead.
- The user wants a developer-facing technical doc — write Markdown directly.
- The user needs to write/update/delete data — this skill is READ-ONLY.
- The user wants to schedule recurring jobs — out of scope.

## Workflow Overview

Follow these seven steps. Do not skip steps. Do not ask the user about technical details.

1. **Parse user input** — extract topic, requested format, attached files, mentioned tables/queries.
2. **Resolve data source** — pick exactly one of: Databricks table, SQL query, attached file(s), inline content. Ask only if ambiguous.
3. **Acquire data** — run the appropriate script under `scripts/`, normalize to JSON.
4. **Analyze deeply** — derive KPIs, trends, comparisons, correlations, outliers via `scripts/statistical_analysis.py`.
5. **Choose report type** — Dashboard, Narrative Report, Explorer, Slideshow Story, or Multi-page composition.
6. **Generate HTML** — copy the right template, inject data, apply palette and non-technical voice, add legends to every visual.
7. **Deliver** — write to `./prisma-output/<slug>/`, run validation, surface the path and how to open it.

Read the section for the current step and the referenced files before acting. Do not improvise on guarded sections.

## Step 1 — Parse User Input

Extract from the prompt that came with `/prisma`:

- **Topic / focus** (e.g. "Q4 sales", "user churn", "support tickets"). If absent, target a general overview of all dimensions in the data.
- **Requested format** (dashboard, narrative report, explorer, slideshow). If absent, decide in Step 5 based on the data shape.
- **Source hints** (table name, SQL keywords, file attachment, "paste my notes").
- **Audience hints** (executives, board, marketing team, all-hands). Default: senior non-technical leadership.
- **Custom branding** (color palette, logo URL, component library URL). If the user provided a source for branding, use `WebFetch` to extract palette and component patterns. Otherwise use the default palette from `references/ui/chart-colors.md`.

If the user gave only a topic with no other detail, that is fine — proceed and produce a general analysis.

## Step 2 — Resolve Data Source

The valid sources are exactly three. Detect which one the user intends:

| User signal | Source | Reference |
|---|---|---|
| Mentions a table name only (e.g. "table `sales.orders`"), no SELECT clause | **Table access** (generic report mode) | `references/data-sources/databricks.md` |
| Provides a SQL `SELECT` (or asks to "run this query") | **Query execution** | `references/data-sources/databricks.md` |
| Attaches a file or pastes inline text | **Custom content** | `references/data-sources/files.md` or `references/data-sources/inline-content.md` |

If none of these is clear, ask **one** question with three options:

> Which data source should I use?
> 1. A table I can read from your warehouse (Databricks).
> 2. A SQL query you want me to run (read-only).
> 3. Your own content — a file (PDF, Excel, DOCX, CSV) or pasted text.

After this single clarification, proceed without further questions unless a hard blocker appears (missing credentials, unreadable file).

## Step 3 — Acquire Data

Pick the right script based on the resolved source. All scripts live in `scripts/` and write normalized JSON to `./prisma-output/<slug>/data/dataset.json`.

- **Table or query** → `python scripts/databricks_query.py --mode table --table "<name>" --output ...` or `--mode query --query "<sql>" --output ...`. The script auto-detects which Databricks library is installed.
- **File** → `python scripts/file_parser.py --input <path> --output ...`. Handles PDF, Excel, DOCX, CSV, TXT.
- **Inline content** → write the user's text to a temp `.txt` and run `file_parser.py` against it.

If a Python dependency is missing, the script prints a single `pip install` command. Run it once with `Bash`, then retry. Do not improvise.

Read `references/data-sources/databricks.md` before any warehouse call. The READ-ONLY guardrails there are mandatory.

## Step 4 — Analyze Deeply

Run `python scripts/statistical_analysis.py --input <dataset.json> --output <analysis.json>`. The script returns a structured object containing:

- Inferred column types (categorical, numeric, temporal, identifier, free-text).
- Descriptive statistics per numeric column (count, mean, median, std, min, max, p25, p50, p75, p95).
- Top-N value counts per categorical column.
- Time-series trends (rolling averages, period-over-period change) when a temporal column exists.
- Correlations between numeric columns (Pearson, only |r| >= 0.3 reported).
- Outliers (IQR rule, only the top 10 most extreme).
- A ranked list of "insight candidates" — headline-worthy facts with a relevance score.

Combine these mechanical findings with the user's stated focus to write the **storytelling outline** (see `references/analysis/storytelling.md`).

If the user gave a narrow focus (e.g. "only churn"), filter the insight candidates accordingly. If the user gave no focus, present a general analysis covering the strongest 5–8 insight candidates.

## Step 5 — Choose Report Type

Use this decision tree:

| Conditions | Report type | Reference |
|---|---|---|
| User asked for "dashboard", or source = full table with multiple metrics, or audience = leadership monitoring | **Dashboard** (default) | `references/report-types/dashboard.md` |
| User asked for "report", "analysis", "explain", "why", "writeup" | **Narrative Report** | `references/report-types/narrative-report.md` |
| User asked for "explore", "filter", "drill down", "investigate" | **Dataset Explorer** | `references/report-types/explorer.md` |
| User asked for "slides", "slideshow", "presentation", "story", "deck" | **Slideshow Story** | `references/report-types/slideshow-story.md` |
| Data has 2+ uncorrelated themes (e.g. revenue + support + product usage) AND total content exceeds one comfortable page | **Multi-page** wrapper containing one of the above per page | `references/ui/multi-page-nav.md` |

If still ambiguous, default to Dashboard.

## Step 6 — Generate HTML

1. Pick a template from `templates/`:
   - `standalone-base.html` — single self-contained file (Dashboard / Narrative Report under ~400 KB of data).
   - `multi-page-base/` — folder with `index.html` plus `pages/<topic>.html`.
   - `slideshow-base.html` — 16:9 carousel with keyboard navigation.
2. Inject the dataset as inline JSON inside `<script id="report-data" type="application/json">...</script>`. For datasets > 500 KB, write to `data/dataset.json` and `fetch` it with a same-origin guard (multi-page mode only).
3. Build the chart specs by reading `references/ui/chart-patterns.md`. Pick chart types from `references/analysis/insight-extraction.md` based on the (dimension × metric) shape.
4. Apply the palette and chart rules from `references/ui/chart-colors.md`. Do not invent new colors.
5. Apply controls from `references/ui/controls.md` (dark mode toggle, print/PDF, refresh hint, CSV download per chart, filter bar).
6. Apply layout responsiveness from `references/ui/responsive-layout.md`. Every report must work cleanly on phone (375px), tablet (768px), desktop (1280px+), and print.
7. Apply the non-technical voice rules from `references/voice/non-technical-audience.md` and `references/voice/anti-ai-slop.md`.
8. Add a legend block to every KPI and chart per `references/analysis/data-legends.md`. No exceptions.
9. Build the storytelling flow per `references/analysis/storytelling.md`. Each section must connect context → evidence → implication.

## Step 7 — Deliver

1. Write the output to `./prisma-output/<slug>/`. The slug is `<topic-kebab>-<type>` (e.g. `q4-sales-dashboard`).
2. Run `python scripts/validate_report.py --path ./prisma-output/<slug>/`. It checks:
   - Every chart has a `<figcaption>` with source, definition, unit, period.
   - No banned words appear (see `references/voice/anti-ai-slop.md`).
   - No emojis appear in the rendered HTML.
   - All inline JSON parses.
   - Internal links resolve (multi-page).
   - Mobile breakpoints render (smoke check via DOM scan for `min-h-screen`, `max-w-*`, `grid-cols-*`).
3. Print the absolute path of the entry HTML and the command to open it (`open <path>` on macOS, `xdg-open <path>` on Linux, `start <path>` on Windows).
4. If anything failed validation, fix it and re-run validation. Do not deliver a failing report.

## Read These Before Acting

The first time the skill runs in a session, read in this order:

1. `references/voice/non-technical-audience.md`
2. `references/voice/anti-ai-slop.md`
3. `references/ui/responsive-layout.md`
4. `references/analysis/data-legends.md`

These four define invariants that apply to every report regardless of type.

Then, on demand, read the file that matches the current step. Do not preload everything.

<guardrails>

**Data access is READ-ONLY.** This is not negotiable.

- Reject any user-supplied SQL containing `INSERT`, `UPDATE`, `DELETE`, `MERGE`, `DROP`, `TRUNCATE`, `ALTER`, `CREATE`, `REPLACE`, `GRANT`, `REVOKE`, `COPY`, `LOAD`, `UNLOAD`, `CALL`, or `EXECUTE` (case-insensitive, word-boundary regex). The check is implemented in `scripts/databricks_query.py`. Do not bypass it.
- Never interpolate raw user strings into SQL. When parameterized queries are not supported by the driver (warehouses generally reject `params`), validate identifiers against a strict allowlist before string-concatenating.
- Use machine-to-machine credentials. Read host, HTTP path, and token from environment variables (`DATABRICKS_HOST`, `DATABRICKS_HTTP_PATH`, `DATABRICKS_TOKEN`). Never write credentials to any output file.
- Before reading any file matching `.gitignore` patterns (`.env*`, `credentials.*`, `secrets.*`, `*.key`, `*.pem`), ask the user explicit permission. State the exact path and the reason.
- All output goes only into `./prisma-output/<slug>/`. Never write outside that directory.

</guardrails>

<audience_voice>

The audience is non-technical. Lead with the answer. Then the evidence. Then the context.

- Inline-define any acronym or technical term on its first appearance (e.g. "AOV (average order value, total revenue divided by number of orders)").
- Every KPI and chart MUST display: title, source, definition, unit, time period.
- Banned AI-slop words (strike on sight): `magic`, `delight`, `seamless`, `unlock`, `rethink`, `supercharge`, `leverage`, `empower`, `game-changer`, `revolutionize`, `transform`, `synergy`, `paradigm`. Replace each one with a concrete claim or delete the line.
- Zero emojis in the rendered report. Zero emojis in the skill files.
- Replace jargon with plain language. "Throughput" becomes "items processed per hour". "Cohort" becomes "group of users that signed up in the same week".
- Numbers larger than 9999 use thousand separators per the report's locale (default `en-US`: `12,345`; if user data is in pt-BR locale: `12.345`).
- Percentages always show direction and baseline (e.g. "12% higher than Q3", not just "12%").

</audience_voice>

<minimal_interaction>

- Ask the user only when truly necessary. Maximum one clarifying question per missing critical input.
- Never ask about colors, fonts, libraries, or layout. Decide internally.
- Never ask about technical details (connection strings, file paths, library names). Detect or default.
- If a credential or attached file is missing, ask once with a single concrete question.

</minimal_interaction>

<responsiveness_invariants>

Every report MUST be fully responsive. No exceptions, regardless of report type.

- Use a mobile-first approach. The base layout works at 375px wide.
- Breakpoints (Tailwind defaults): `sm` 640px, `md` 768px, `lg` 1024px, `xl` 1280px, `2xl` 1536px.
- Grid containers use `grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4` for KPI rows.
- Chart wrappers use `aspect-[16/9] sm:aspect-[4/3] lg:aspect-[16/9]` or fixed responsive heights via `h-64 sm:h-72 lg:h-96`.
- Navigation collapses to a hamburger or bottom tab bar below `md`.
- Tables use horizontal scroll containers (`overflow-x-auto`) with sticky first column on mobile.
- Slideshow slides scale via `vw`/`vh` units AND have a mobile fallback that stacks the slide content vertically below 640px.
- Touch targets are at least 44x44 px.
- Print stylesheet forces light mode, hides controls (`print:hidden`), and sets `@page { margin: 12mm }`.

Read `references/ui/responsive-layout.md` for the complete checklist before generating any HTML.

</responsiveness_invariants>

<implementation_checklist>

Before delivering, verify each item:

- [ ] Data source verified READ-ONLY.
- [ ] All KPIs and charts have title + source + definition + unit + period legend.
- [ ] CHART_COLORS palette applied consistently.
- [ ] Dark mode toggle works.
- [ ] Print/PDF button triggers `window.print()`.
- [ ] Category and date filters present (when data has those dimensions).
- [ ] CSV download button per chart.
- [ ] Multi-page navigation works (when applicable).
- [ ] Slideshow keyboard nav works (← → arrows, Space to advance, Esc to exit fullscreen) when applicable.
- [ ] No banned AI-slop words appear in the rendered HTML.
- [ ] No emojis appear in the rendered HTML.
- [ ] Storytelling: each section connects context → evidence → implication.
- [ ] Layout renders correctly at 375px, 768px, 1280px, and in print preview.
- [ ] All touch targets ≥ 44x44 px.
- [ ] Output saved to `./prisma-output/<slug>/`.
- [ ] `validate_report.py` passed.

</implementation_checklist>

## File Index

References (read on demand):

- `references/data-sources/databricks.md` — Databricks read-only access, three connector options, dialect, schema exploration.
- `references/data-sources/files.md` — PDF / Excel / DOCX / CSV / TXT parsing patterns and normalized JSON shape.
- `references/data-sources/inline-content.md` — Handling pasted notes and free-form text.
- `references/report-types/dashboard.md` — KPI grid + chart matrix + filter bar.
- `references/report-types/narrative-report.md` — Vertical scroll story with executive summary.
- `references/report-types/explorer.md` — Sidebar filters with reactive charts and tables.
- `references/report-types/slideshow-story.md` — 16:9 carousel with keyboard navigation.
- `references/ui/chart-patterns.md` — ECharts recipes for 8 chart types.
- `references/ui/chart-colors.md` — Palette, semantic color rules, dark mode adaptations.
- `references/ui/controls.md` — Dark toggle, print, refresh, CSV export, filter bar.
- `references/ui/multi-page-nav.md` — Sidebar / topnav with Alpine.js, mobile collapse.
- `references/ui/slideshow-carousel.md` — Carousel mechanics (keyboard, touch swipe, indicator).
- `references/ui/responsive-layout.md` — Breakpoints, grid templates, mobile rules, print rules.
- `references/analysis/insight-extraction.md` — How to derive KPIs and pick chart types.
- `references/analysis/statistical-summary.md` — Pandas operations and what they mean.
- `references/analysis/storytelling.md` — Pyramid structure (answer → evidence → implication).
- `references/analysis/data-legends.md` — Mandatory legend format for every visual.
- `references/voice/non-technical-audience.md` — Vocabulary, glossary, plain-language rules.
- `references/voice/anti-ai-slop.md` — Banned words, executive tone.
- `references/exporting/pdf-print.md` — Print stylesheet rules.
- `references/exporting/share.md` — Standalone vs multi-file delivery decision.

Templates:

- `templates/standalone-base.html` — Single-file dashboard or narrative report.
- `templates/multi-page-base/` — Folder with `index.html` and per-topic pages.
- `templates/slideshow-base.html` — 16:9 carousel with mobile vertical fallback.
- `templates/partials/` — Reusable HTML fragments (KPI card, chart card, filter bar, nav, slide frame).

Scripts:

- `scripts/databricks_query.py` — Read-only Databricks executor with auto-detected connector.
- `scripts/file_parser.py` — PDF / Excel / DOCX / CSV / TXT to normalized JSON.
- `scripts/statistical_analysis.py` — Pandas-based analysis returning insight candidates.
- `scripts/validate_report.py` — Pre-delivery validation suite.

## Quality Bar

> Your goal is to create executive-grade insight reports. Every report should look like it was built by a top-tier analytics consultancy. Reject mediocrity. Build something with a point of view.

> One thousand no's for every yes. Never pad the report with placeholder text, dummy numbers, or generic icons just to fill space. Empty space is fine. Wrong content is not.

> User-supplied copy is canonical. Use it verbatim wherever it fits.
