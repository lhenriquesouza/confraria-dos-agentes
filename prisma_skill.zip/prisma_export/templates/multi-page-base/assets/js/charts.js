/* Shared ECharts factory for multi-page reports. */

const CHART_COLORS = {
  blue: '#0079F2', purple: '#795EFF', green: '#009118',
  red: '#A60808', amber: '#D97706', pink: '#EC4899',
  teal: '#0D9488', slate: '#64748B',
};
const CHART_COLOR_LIST = [
  CHART_COLORS.blue, CHART_COLORS.purple, CHART_COLORS.teal,
  CHART_COLORS.amber, CHART_COLORS.pink, CHART_COLORS.green,
  CHART_COLORS.red, CHART_COLORS.slate,
];
const SEQUENTIAL = ['#EFF6FF', '#BFDBFE', '#60A5FA', '#2563EB', '#1E40AF'];

function themeTokens() {
  const dark = document.documentElement.classList.contains('dark');
  return {
    dark, bg: dark ? '#18181B' : '#FFFFFF',
    grid: dark ? 'rgba(255,255,255,0.06)' : '#F4F4F5',
    axis: dark ? 'rgba(255,255,255,0.12)' : '#E4E4E7',
    tick: dark ? '#A1A1AA' : '#71717A',
    text: dark ? '#F4F4F5' : '#18181B',
    border: dark ? '#3F3F46' : '#E4E4E7',
  };
}

function baseOption() {
  const t = themeTokens();
  return {
    animation: false,
    grid: { top: 36, right: 20, bottom: 44, left: 56, containLabel: true },
    textStyle: { fontFamily: 'Inter, system-ui, sans-serif' },
    tooltip: {
      trigger: 'axis', backgroundColor: t.bg, borderColor: t.border, borderWidth: 1,
      textStyle: { color: t.text, fontSize: 12 },
      extraCssText: 'box-shadow: 0 8px 24px rgba(0,0,0,.10); border-radius: 8px;',
    },
    legend: { bottom: 0, icon: 'roundRect', itemWidth: 10, itemHeight: 10, textStyle: { color: t.tick, fontSize: 11 } },
  };
}

function buildOption(spec) {
  const t = themeTokens(); const base = baseOption();
  switch (spec.type) {
    case 'line':
      return Object.assign({}, base, {
        xAxis: { type: 'category', data: spec.x, boundaryGap: false,
                 axisLine: { lineStyle: { color: t.axis } }, axisLabel: { color: t.tick, fontSize: 11 } },
        yAxis: { type: 'value', splitLine: { lineStyle: { color: t.grid } },
                 axisLabel: { color: t.tick, formatter: window.numberFormat, fontSize: 11 } },
        series: (spec.series || []).map((s, i) => ({
          name: s.name, type: 'line', data: s.data, smooth: false, showSymbol: false,
          lineStyle: { width: 2, color: CHART_COLOR_LIST[i] },
        })),
      });
    case 'bar':
      return Object.assign({}, base, {
        xAxis: { type: 'category', data: spec.x,
                 axisLabel: { interval: 0, rotate: spec.x && spec.x.length > 6 ? -30 : 0,
                              color: t.tick, fontSize: 11 } },
        yAxis: { type: 'value', splitLine: { lineStyle: { color: t.grid } },
                 axisLabel: { color: t.tick, formatter: window.numberFormat, fontSize: 11 } },
        series: (spec.series || []).map((s, i) => ({
          name: s.name, type: 'bar', data: s.data,
          itemStyle: { color: CHART_COLOR_LIST[i], borderRadius: [4,4,0,0] }, barMaxWidth: 48,
        })),
      });
    case 'hbar':
      return Object.assign({}, base, {
        grid: { top: 16, right: 24, bottom: 24, left: 120, containLabel: true },
        xAxis: { type: 'value', splitLine: { lineStyle: { color: t.grid } },
                 axisLabel: { color: t.tick, formatter: window.numberFormat, fontSize: 11 } },
        yAxis: { type: 'category', data: spec.y, inverse: true,
                 axisTick: { show: false }, axisLine: { show: false },
                 axisLabel: { color: t.tick, fontSize: 12 } },
        series: [{ type: 'bar', data: spec.values,
                   itemStyle: { color: CHART_COLORS.blue, borderRadius: [0,4,4,0] },
                   label: { show: true, position: 'right', formatter: (p) => window.numberFormat(p.value), color: t.tick, fontSize: 11 } }],
      });
    case 'pie': case 'donut':
      return Object.assign({}, base, {
        tooltip: Object.assign({}, base.tooltip, { trigger: 'item' }),
        series: [{
          type: 'pie', radius: spec.type === 'donut' ? ['55%', '80%'] : ['0%', '78%'],
          center: ['50%', '50%'], avoidLabelOverlap: true, padAngle: 2,
          itemStyle: { borderRadius: 4, borderColor: t.bg, borderWidth: 2 },
          label: { show: true, formatter: '{b}\n{d}%', color: t.tick, fontSize: 11 },
          data: (spec.data || []).map((it, i) => ({
            name: it.label, value: it.value,
            itemStyle: { color: CHART_COLOR_LIST[i % CHART_COLOR_LIST.length] },
          })),
        }],
      });
    case 'scatter':
      return Object.assign({}, base, {
        tooltip: Object.assign({}, base.tooltip, { trigger: 'item' }),
        xAxis: { type: 'value', name: spec.xLabel, splitLine: { lineStyle: { color: t.grid } }, axisLabel: { color: t.tick, fontSize: 11 } },
        yAxis: { type: 'value', name: spec.yLabel, splitLine: { lineStyle: { color: t.grid } }, axisLabel: { color: t.tick, fontSize: 11 } },
        series: [{ type: 'scatter', symbolSize: 8, itemStyle: { color: CHART_COLORS.blue, opacity: 0.65 }, data: spec.data || [] }],
      });
    case 'heatmap':
      return Object.assign({}, base, {
        tooltip: Object.assign({}, base.tooltip, { trigger: 'item', position: 'top' }),
        grid: { top: 16, right: 16, bottom: 56, left: 80 },
        xAxis: { type: 'category', data: spec.xLabels, splitArea: { show: true }, axisLabel: { color: t.tick, fontSize: 11 } },
        yAxis: { type: 'category', data: spec.yLabels, splitArea: { show: true }, axisLabel: { color: t.tick, fontSize: 11 } },
        visualMap: { min: spec.min || 0, max: spec.max, calculable: true, orient: 'horizontal', left: 'center', bottom: 0, inRange: { color: SEQUENTIAL }, textStyle: { color: t.tick, fontSize: 10 } },
        series: [{ type: 'heatmap', data: spec.cells }],
      });
    case 'gauge':
      return Object.assign({}, base, {
        series: [{
          type: 'gauge', startAngle: 200, endAngle: -20,
          min: 0, max: spec.goal, splitNumber: 5,
          axisLine: { lineStyle: { width: 18, color: [
            [Math.min(1, spec.current / spec.goal), CHART_COLORS.blue],
            [1, t.grid],
          ] } },
          pointer: { show: false }, axisTick: { show: false }, splitLine: { show: false },
          axisLabel: { show: false },
          detail: { valueAnimation: false, fontSize: 28, fontWeight: 'bold', formatter: window.numberFormat, color: t.text, offsetCenter: [0, '0%'] },
          data: [{ value: spec.current }],
        }],
      });
    default:
      return base;
  }
}

window.CHART_COLORS = CHART_COLORS;
window.CHART_COLOR_LIST = CHART_COLOR_LIST;
window.buildOption = buildOption;
