/* Shared app JS for multi-page reports — theme + utilities. */

const THEME_KEY = 'prisma-reports-theme';
const LOCALE = document.documentElement.lang || 'en-US';

function applyTheme(theme) {
  document.documentElement.classList.toggle('dark', theme === 'dark');
  document.documentElement.dataset.theme = theme;
  document.documentElement.dispatchEvent(new CustomEvent('themechange', { detail: { theme } }));
  localStorage.setItem(THEME_KEY, theme);
}
function toggleTheme() {
  const cur = document.documentElement.classList.contains('dark') ? 'dark' : 'light';
  applyTheme(cur === 'dark' ? 'light' : 'dark');
}
(function () {
  const stored = localStorage.getItem(THEME_KEY);
  const prefers = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  applyTheme(stored || prefers);
})();
window.toggleTheme = toggleTheme;

function numberFormat(v) {
  if (v == null || isNaN(v)) return '';
  if (Math.abs(v) >= 1e9) return (v / 1e9).toFixed(1) + 'B';
  if (Math.abs(v) >= 1e6) return (v / 1e6).toFixed(1) + 'M';
  if (Math.abs(v) >= 1e3) return (v / 1e3).toFixed(1) + 'k';
  if (Number.isInteger(v)) return v.toLocaleString(LOCALE);
  return v.toLocaleString(LOCALE, { maximumFractionDigits: 2 });
}
window.numberFormat = numberFormat;
