/* Shared filter logic for explorer-style multi-page reports. */

function passesFilters(row, activeFacets, dateFilter, activeDateFilter) {
  for (const [name, values] of Object.entries(activeFacets || {})) {
    if (values && values.length) {
      if (!values.includes(row[name])) return false;
    }
  }
  if (dateFilter && activeDateFilter && activeDateFilter !== 'all') {
    const ts = new Date(row[dateFilter.column]);
    if (isNaN(ts)) return false;
    const now = new Date();
    const cutoffs = {
      '7d':  new Date(now - 7  * 86400e3),
      '30d': new Date(now - 30 * 86400e3),
      '90d': new Date(now - 90 * 86400e3),
      'ytd': new Date(now.getFullYear(), 0, 1),
    };
    const cutoff = cutoffs[activeDateFilter];
    if (cutoff && ts < cutoff) return false;
  }
  return true;
}

function downloadCSV(rows, filename) {
  if (!rows || !rows.length) return;
  const headers = Object.keys(rows[0]);
  const escape = v => '"' + String(v ?? '').replace(/"/g, '""') + '"';
  const csv = [headers.join(','), ...rows.map(r => headers.map(h => escape(r[h])).join(','))].join('\n');
  const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename || 'data.csv'; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

window.passesFilters = passesFilters;
window.downloadCSV = downloadCSV;
