#!/usr/bin/env python3
"""
validate_report.py — Pre-delivery validation suite for an insights report.

Checks:
  * Every <figure> contains a <figcaption> with Source / Definition / Unit / Period.
  * No banned AI-slop words in rendered text.
  * No emojis in rendered text.
  * Embedded JSON parses (script tags with type=application/json).
  * Internal links resolve (multi-page only).
  * Mobile / responsive smoke check (presence of mobile-first utilities).
  * Touch targets: detects buttons without min-h-[44px] / min-w-[44px] or larger explicit sizes.

Usage:
  python validate_report.py --path ./prisma-output/<slug>/

Exit code 0 = OK; non-zero = at least one failure.
"""
from __future__ import annotations

import argparse
import glob
import html
import json
import os
import re
import sys
from typing import Iterable

BANNED_RE = re.compile(
    r"\b("
    r"magic|delight|seamless|unlock\w*|rethink\w*|supercharge\w*|leverag\w*|empower\w*|"
    r"game[-\s]?changer|revolutioni[sz]e|transform|synerg\w*|paradigm|"
    r"robust|holistic|disruptive|cutting[-\s]edge|world[-\s]class|best[-\s]in[-\s]class|"
    r"streamlin\w*|optimi[sz]\w*"
    r")\b",
    re.IGNORECASE,
)
EMOJI_RE = re.compile(
    "["
    "\U0001F300-\U0001FAFF"
    "\U00002600-\U000027BF"
    "\U0001F600-\U0001F64F"
    "\U0001F900-\U0001F9FF"
    "\U0001FA70-\U0001FAFF"
    "]"
)
LEGEND_FIELDS = ("Source", "Definition", "Unit", "Period")
RESPONSIVE_HINTS = ("max-w-[", "grid-cols-1", "sm:grid-cols", "md:grid-cols", "lg:grid-cols", "px-4 sm:px-6", "min-h-[44px]")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--path", required=True, help="Path to a generated report (file or directory).")
    ap.add_argument("--template", action="store_true",
                    help="Template mode: skip placeholder/legend checks (use to lint raw templates).")
    args = ap.parse_args()

    target = os.path.abspath(args.path)
    if not os.path.exists(target):
        print(f"ERROR: path not found: {target}", file=sys.stderr); return 2

    if os.path.isfile(target):
        html_files = [target]
    else:
        html_files = sorted(glob.glob(os.path.join(target, "**", "*.html"), recursive=True))
        if not html_files:
            print(f"ERROR: no .html files found under {target}", file=sys.stderr); return 2

    failures: list[str] = []

    for path in html_files:
        with open(path, "r", encoding="utf-8") as f:
            content = f.read()
        rendered = strip_scripts_and_styles(content)
        for issue in check_emoji(path, rendered):    failures.append(issue)
        for issue in check_banned(path, rendered):   failures.append(issue)
        if not args.template:
            for issue in check_legends(path, content):   failures.append(issue)
            for issue in check_inline_json(path, content): failures.append(issue)
        for issue in check_responsive(path, content): failures.append(issue)

    # Multi-file link resolution
    if os.path.isdir(target):
        for issue in check_internal_links(target, html_files): failures.append(issue)

    if failures:
        print("\nVALIDATION FAILED — fix the items below and re-run:\n")
        for f in failures:
            print(f"  - {f}")
        print(f"\nTotal issues: {len(failures)}")
        return 1
    print(f"OK — validated {len(html_files)} file(s).")
    return 0


def strip_scripts_and_styles(content: str) -> str:
    s = re.sub(r"<script[\s\S]*?</script>", " ", content, flags=re.IGNORECASE)
    s = re.sub(r"<style[\s\S]*?</style>", " ", s, flags=re.IGNORECASE)
    s = re.sub(r"<!--[\s\S]*?-->", " ", s)
    text = re.sub(r"<[^>]+>", " ", s)
    return html.unescape(text)


def check_emoji(path: str, text: str) -> Iterable[str]:
    for m in EMOJI_RE.finditer(text):
        line = text.count("\n", 0, m.start()) + 1
        yield f"{path}: emoji '{m.group(0)}' found near line {line}. Remove it."
        return


def check_banned(path: str, text: str) -> Iterable[str]:
    seen = set()
    for m in BANNED_RE.finditer(text):
        word = m.group(0).lower()
        if word in seen: continue
        seen.add(word)
        line = text.count("\n", 0, m.start()) + 1
        yield f"{path}: banned word '{m.group(0)}' near line {line}. Replace with a concrete claim."


def check_legends(path: str, content: str) -> Iterable[str]:
    figures = re.findall(r"<figure\b[\s\S]*?</figure>", content, re.IGNORECASE)
    for i, fig in enumerate(figures, start=1):
        cap = re.search(r"<figcaption\b[\s\S]*?</figcaption>", fig, re.IGNORECASE)
        if not cap:
            yield f"{path}: <figure> #{i} is missing a <figcaption> legend."
            continue
        cap_html = cap.group(0)
        # If the caption is bound to a single Alpine expression that points to a
        # pre-formatted legend string (e.g. x-text="sec.legend"), treat as valid.
        if re.search(r'x-text="[^"]*\blegend\b[^"]*"', cap_html):
            continue
        cap_text = re.sub(r"<[^>]+>", " ", cap_html)
        for field in LEGEND_FIELDS:
            if field.lower() not in cap_text.lower():
                yield f"{path}: <figure> #{i} legend is missing '{field}'."


def check_inline_json(path: str, content: str) -> Iterable[str]:
    pat = re.compile(r"<script[^>]*type=[\"']application/json[\"'][^>]*>([\s\S]*?)</script>", re.IGNORECASE)
    for i, m in enumerate(pat.finditer(content), start=1):
        body = m.group(1).strip()
        if not body or body in ("{{REPORT_DATA_JSON}}", "{{SLIDES_DATA_JSON}}", "{{HUB_DATA_JSON}}", "{{NAV_LINKS_JSON}}", "{{PAGE_DATA_JSON}}"):
            yield f"{path}: inline JSON #{i} placeholder was not replaced."
            continue
        try:
            json.loads(body)
        except Exception as e:
            yield f"{path}: inline JSON #{i} is invalid: {e}"


def check_responsive(path: str, content: str) -> Iterable[str]:
    misses = [hint for hint in RESPONSIVE_HINTS if hint not in content]
    if len(misses) >= 4:
        yield f"{path}: responsive layout hints missing ({', '.join(misses[:6])}). Verify mobile-first markup."

    # Buttons without explicit touch sizing or text are flagged (heuristic)
    btns = re.findall(r"<button\b[^>]*>", content, re.IGNORECASE)
    bad = [b for b in btns if "touch-tgt" not in b and "min-h-[" not in b and "min-h-12" not in b and "py-3" not in b and "py-2.5" not in b]
    if len(bad) > 4:
        yield f"{path}: {len(bad)} <button> elements lack touch-target sizing (touch-tgt / min-h-[44px] / py-3)."


def check_internal_links(root: str, files: list[str]) -> Iterable[str]:
    file_set = {os.path.normpath(p) for p in files}
    href_pat = re.compile(r"href=[\"']([^\"'#?]+\.html)(?:[#?][^\"']*)?[\"']", re.IGNORECASE)
    for path in files:
        d = os.path.dirname(path)
        with open(path, "r", encoding="utf-8") as f:
            content = f.read()
        for m in href_pat.finditer(content):
            target = os.path.normpath(os.path.join(d, m.group(1)))
            if target not in file_set and not os.path.exists(target):
                yield f"{path}: broken internal link → {m.group(1)}"


if __name__ == "__main__":
    sys.exit(main())
