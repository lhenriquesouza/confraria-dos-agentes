#!/usr/bin/env python3
"""
file_parser.py — Parse user-attached files into a normalized dataset.json.

Supported: .csv, .tsv, .xlsx, .xls, .pdf, .docx, .txt, .md, .json

Usage:
  python file_parser.py --input <path>... --output dataset.json

Output shape:
  {
    "source": { "type": "file" | "multi-file", ... },
    "tables": [ { "name", "columns": [...], "rows": [...] }, ... ],
    "text":   "concatenated free text"
  }

If a parser dependency is missing, prints a single pip install hint.
"""
from __future__ import annotations

import argparse
import csv
import datetime as _dt
import io
import json
import os
import re
import sys
from typing import Any


def hint(pkg: str, reason: str) -> None:
    print(f"ERROR: missing dependency for {reason}.\n  pip install {pkg}", file=sys.stderr)


def parse_csv(path: str) -> dict:
    try:
        import pandas as pd
    except Exception:
        hint("pandas", "CSV parsing")
        sys.exit(10)

    # Sniff delimiter
    delim = ","
    try:
        with open(path, "rb") as f:
            sample_raw = f.read(8192)
        encoding = _detect_encoding(sample_raw)
        sample = sample_raw.decode(encoding, errors="replace")
        try:
            delim = csv.Sniffer().sniff(sample, delimiters=",;\t|").delimiter
        except Exception:
            for c in (",", "\t", ";", "|"):
                if c in sample:
                    delim = c
                    break
    except Exception:
        encoding = "utf-8"

    df = pd.read_csv(path, sep=delim, encoding=encoding, low_memory=False)
    df.columns = [str(c).strip() for c in df.columns]
    return _df_to_table(df, name=os.path.basename(path))


def _detect_encoding(sample: bytes) -> str:
    try:
        import chardet
        guess = chardet.detect(sample)
        if guess and guess.get("encoding"):
            return guess["encoding"]
    except Exception:
        pass
    return "utf-8"


def parse_excel(path: str) -> list[dict]:
    try:
        import pandas as pd  # noqa
    except Exception:
        hint("pandas openpyxl", "Excel parsing")
        sys.exit(11)
    try:
        sheets = _read_excel_safe(path)
    except Exception as e:
        print(f"ERROR: Excel parse failed: {e}", file=sys.stderr)
        return []
    out = []
    for name, df in sheets.items():
        if df is None or df.empty:
            continue
        df.columns = [str(c).strip() for c in df.columns]
        out.append(_df_to_table(df, name=name))
    return out


def _read_excel_safe(path: str):
    import pandas as pd
    try:
        return pd.read_excel(path, sheet_name=None, engine="openpyxl")
    except Exception:
        return pd.read_excel(path, sheet_name=None)


def parse_pdf(path: str) -> dict:
    text_parts: list[str] = []
    tables: list[dict] = []
    warnings: list[str] = []

    # Try text extraction
    try:
        from pypdf import PdfReader
        reader = PdfReader(path)
        for i, page in enumerate(reader.pages, start=1):
            try:
                text_parts.append(page.extract_text() or "")
            except Exception:
                continue
    except Exception:
        hint("pypdf", "PDF text extraction")

    # Density check
    full_text = "\n\n".join(text_parts)
    if len(full_text) < max(200, 50 * len(text_parts)):
        warnings.append("Low text density. PDF may be a scanned image; OCR is recommended.")

    # Try table extraction
    try:
        import pdfplumber
        with pdfplumber.open(path) as pdf:
            for pi, page in enumerate(pdf.pages, start=1):
                try:
                    tbls = page.extract_tables() or []
                except Exception:
                    tbls = []
                for ti, tbl in enumerate(tbls, start=1):
                    if not tbl or len(tbl) < 2:
                        continue
                    headers = [str(h).strip() if h else f"col_{j}" for j, h in enumerate(tbl[0])]
                    rows = []
                    for r in tbl[1:]:
                        rows.append({headers[j]: (str(r[j]).strip() if j < len(r) and r[j] is not None else "") for j in range(len(headers))})
                    tables.append({
                        "name": f"page-{pi}-table-{ti}",
                        "columns": [{"name": h, "type": "string", "comment": None} for h in headers],
                        "rows": rows,
                    })
    except Exception:
        hint("pdfplumber", "PDF table extraction")

    return {"text": full_text, "tables": tables, "warnings": warnings}


def parse_docx(path: str) -> dict:
    try:
        from docx import Document
    except Exception:
        hint("python-docx", "DOCX parsing")
        sys.exit(12)

    doc = Document(path)
    text_parts = []
    tables = []
    table_counter = 0

    for block in _iter_block_items(doc):
        if block.__class__.__name__ == "Paragraph":
            txt = block.text.strip()
            if txt:
                text_parts.append(txt)
        elif block.__class__.__name__ == "Table":
            table_counter += 1
            rows_raw = []
            for row in block.rows:
                rows_raw.append([cell.text.strip() for cell in row.cells])
            if not rows_raw or len(rows_raw) < 2:
                continue
            headers = rows_raw[0] or [f"col_{i}" for i in range(len(rows_raw[1]))]
            rows = [{headers[i]: (r[i] if i < len(r) else "") for i in range(len(headers))} for r in rows_raw[1:]]
            tables.append({
                "name": f"table-{table_counter}",
                "columns": [{"name": h, "type": "string", "comment": None} for h in headers],
                "rows": rows,
            })

    return {"text": "\n\n".join(text_parts), "tables": tables}


def _iter_block_items(parent):
    from docx.document import Document as _Doc
    from docx.oxml.ns import qn
    from docx.table import Table as _Table
    from docx.text.paragraph import Paragraph as _Paragraph

    if isinstance(parent, _Doc):
        parent_elm = parent.element.body
    else:
        parent_elm = parent
    for child in parent_elm.iterchildren():
        if child.tag == qn("w:p"):
            yield _Paragraph(child, parent)
        elif child.tag == qn("w:tbl"):
            yield _Table(child, parent)


def parse_txt(path: str) -> dict:
    encoding = "utf-8"
    try:
        with open(path, "rb") as f:
            sample = f.read(8192)
        encoding = _detect_encoding(sample)
    except Exception:
        pass
    with open(path, "r", encoding=encoding, errors="replace") as f:
        return {"text": f.read(), "tables": []}


def parse_json(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        try:
            data = json.load(f)
        except Exception as e:
            return {"text": "", "tables": [], "warnings": [f"Invalid JSON: {e}"]}
    if isinstance(data, list) and data and isinstance(data[0], dict):
        cols = list({k for row in data for k in row.keys()})
        return {"text": "", "tables": [{
            "name": os.path.basename(path),
            "columns": [{"name": c, "type": _infer_jcol_type(data, c), "comment": None} for c in cols],
            "rows": data,
        }]}
    if isinstance(data, dict) and "columns" in data and "rows" in data:
        return {"text": "", "tables": [{
            "name": os.path.basename(path),
            "columns": [{"name": c, "type": "string", "comment": None} for c in data["columns"]],
            "rows": data["rows"],
        }]}
    return {"text": json.dumps(data, ensure_ascii=False, indent=2), "tables": []}


def _infer_jcol_type(rows: list[dict], col: str) -> str:
    has_int = has_float = False
    for r in rows[:50]:
        v = r.get(col)
        if v is None:
            continue
        if isinstance(v, bool):
            return "boolean"
        if isinstance(v, int):
            has_int = True
        elif isinstance(v, float):
            has_float = True
    if has_float:
        return "number"
    if has_int:
        return "integer"
    return "string"


def _df_to_table(df, name: str) -> dict:
    import pandas as pd
    df = df.copy()
    # Cap rows
    sample_note = None
    if len(df) > 100_000:
        df = df.sample(100_000, random_state=42).sort_index()
        sample_note = "Sampled to 100,000 rows."
    cols = []
    for c in df.columns:
        s = df[c]
        if pd.api.types.is_bool_dtype(s):
            t = "boolean"
        elif pd.api.types.is_integer_dtype(s):
            t = "integer"
        elif pd.api.types.is_float_dtype(s):
            t = "number"
        elif pd.api.types.is_datetime64_any_dtype(s):
            t = "timestamp"
            df[c] = s.dt.tz_localize(None) if hasattr(s.dt, "tz_localize") and s.dt.tz else s
            df[c] = df[c].dt.strftime("%Y-%m-%dT%H:%M:%S")
        else:
            t = "string"
            # Try datetime parse
            try:
                parsed = pd.to_datetime(s, errors="coerce", utc=False, infer_datetime_format=True)
                if parsed.notna().mean() > 0.9 and parsed.notna().sum() > 5:
                    t = "timestamp"
                    df[c] = parsed.dt.strftime("%Y-%m-%dT%H:%M:%S")
            except Exception:
                pass
        cols.append({"name": str(c), "type": t, "comment": None})

    df = df.where(df.notna(), None)
    rows = df.to_dict(orient="records")
    table = {"name": name, "columns": cols, "rows": rows}
    if sample_note:
        table["note"] = sample_note
    return table


def parse_one(path: str) -> dict:
    ext = os.path.splitext(path)[1].lower()
    if ext in (".csv", ".tsv"):
        return {"text": "", "tables": [parse_csv(path)]}
    if ext in (".xlsx", ".xls"):
        return {"text": "", "tables": parse_excel(path)}
    if ext == ".pdf":
        return parse_pdf(path)
    if ext == ".docx":
        return parse_docx(path)
    if ext in (".txt", ".md", ".markdown"):
        return parse_txt(path)
    if ext == ".json":
        return parse_json(path)
    raise SystemExit(f"ERROR: unsupported file extension: {ext} ({path})")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", nargs="+", required=True, help="One or more files to parse.")
    ap.add_argument("--output", required=True, help="Path to write dataset.json")
    args = ap.parse_args()

    if len(args.input) == 1:
        path = args.input[0]
        if not os.path.exists(path):
            print(f"ERROR: file not found: {path}", file=sys.stderr); return 2
        size = os.path.getsize(path)
        if size > 50 * 1024 * 1024:
            print(f"ERROR: file too large ({size} bytes). Max 50 MB.", file=sys.stderr); return 3
        parsed = parse_one(path)
        out = {
            "source": {
                "type": "file",
                "format": os.path.splitext(path)[1].lstrip("."),
                "filename": os.path.basename(path),
                "filesize_bytes": size,
                "parsed_at": _dt.datetime.utcnow().isoformat() + "Z",
                "warnings": parsed.get("warnings", []),
            },
            "tables": parsed.get("tables", []),
            "text": parsed.get("text", ""),
        }
    else:
        all_tables = []
        all_text = []
        files_meta = []
        for path in args.input:
            if not os.path.exists(path):
                print(f"WARN: skipping missing file: {path}", file=sys.stderr); continue
            parsed = parse_one(path)
            base = os.path.basename(path)
            for t in parsed.get("tables", []):
                t = dict(t); t["name"] = f"{base}/{t['name']}"
                all_tables.append(t)
            txt = parsed.get("text", "").strip()
            if txt:
                all_text.append(f"--- FROM {base} ---\n\n{txt}")
            files_meta.append({"filename": base, "format": os.path.splitext(path)[1].lstrip(".")})
        out = {
            "source": {
                "type": "multi-file",
                "files": files_meta,
                "parsed_at": _dt.datetime.utcnow().isoformat() + "Z",
                "warnings": [],
            },
            "tables": all_tables,
            "text": "\n\n".join(all_text),
        }

    os.makedirs(os.path.dirname(os.path.abspath(args.output)) or ".", exist_ok=True)
    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, default=str)
    print(f"Wrote {args.output}  tables={len(out.get('tables', []))}  text_len={len(out.get('text',''))}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
