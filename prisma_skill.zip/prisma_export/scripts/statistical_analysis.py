#!/usr/bin/env python3
"""
statistical_analysis.py — Derive insights from a normalized dataset.json.

Usage:
  python statistical_analysis.py --input dataset.json --output analysis.json [--focus "topic words"]

Input shape (Databricks-mode):
  { "source": {...}, "columns": [...], "rows": [...] }

Input shape (file-mode):
  { "source": {...}, "tables": [{ "name", "columns", "rows" }, ...], "text": "..." }

Output shape (analysis.json) — see references/analysis/statistical-summary.md.
"""
from __future__ import annotations

import argparse
import datetime as _dt
import json
import math
import os
import re
import sys
from typing import Any


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--output", required=True)
    ap.add_argument("--focus", default="", help="Optional topic focus for ranking insights.")
    args = ap.parse_args()

    with open(args.input, "r", encoding="utf-8") as f:
        data = json.load(f)

    try:
        import pandas as pd
    except Exception:
        print("ERROR: missing dependency for statistical analysis.\n  pip install pandas numpy", file=sys.stderr)
        return 10

    # Pick the largest table (Databricks output uses {columns, rows}; file output uses {tables: [...]})
    if "tables" in data and data["tables"]:
        table = max(data["tables"], key=lambda t: len(t.get("rows", [])))
        cols = table.get("columns", [])
        rows = table.get("rows", [])
    else:
        cols = data.get("columns", [])
        rows = data.get("rows", [])

    df = pd.DataFrame(rows)
    if df.empty:
        analysis = _empty_analysis(rows, cols)
    else:
        analysis = _analyze(df, cols, args.focus)

    # Mine free text for named numbers (when present)
    text = data.get("text", "")
    if text:
        analysis["text_facts"] = _mine_text_facts(text)

    os.makedirs(os.path.dirname(os.path.abspath(args.output)) or ".", exist_ok=True)
    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(analysis, f, ensure_ascii=False, default=str)
    print(f"Wrote {args.output}  rows={len(rows)}  cols={len(cols)}  insights={len(analysis.get('insights', []))}")
    return 0


def _empty_analysis(rows, cols):
    return {
        "summary": {"row_count": len(rows), "column_count": len(cols), "time_span_days": None,
                    "primary_metric": None, "primary_dimension": None, "primary_temporal": None},
        "columns": {}, "aggregations": {}, "time_series": {},
        "correlations": [], "outliers": [], "insights": [],
    }


def _analyze(df, schema_cols, focus: str) -> dict:
    import pandas as pd
    import numpy as np

    analysis = {
        "summary": {},
        "columns": {},
        "aggregations": {},
        "time_series": {},
        "correlations": [],
        "outliers": [],
        "insights": [],
    }

    # Detect column kinds
    column_kinds = {}
    for c in df.columns:
        s = df[c]
        kind = "string"
        if pd.api.types.is_bool_dtype(s): kind = "boolean"
        elif pd.api.types.is_integer_dtype(s) or pd.api.types.is_float_dtype(s): kind = "numeric"
        elif pd.api.types.is_datetime64_any_dtype(s): kind = "temporal"
        else:
            try:
                parsed = pd.to_datetime(s, errors="coerce", utc=False, infer_datetime_format=True)
                if parsed.notna().mean() > 0.9 and parsed.notna().sum() > 3:
                    kind = "temporal"
                    df[c] = parsed
            except Exception:
                pass
            if kind == "string":
                if s.nunique(dropna=True) > 200 and s.astype(str).str.len().mean() > 20:
                    kind = "freetext"
                elif s.nunique(dropna=True) == len(df):
                    kind = "identifier"
                else:
                    kind = "categorical"
        column_kinds[c] = kind

    # Per-column stats
    for c, kind in column_kinds.items():
        s = df[c]
        if kind == "numeric":
            sn = pd.to_numeric(s, errors="coerce")
            stats = {
                "type": "numeric",
                "count": int(sn.notna().sum()),
                "null_rate": float(s.isna().mean()),
                "mean":   _safe_float(sn.mean()),
                "median": _safe_float(sn.median()),
                "std":    _safe_float(sn.std()),
                "min":    _safe_float(sn.min()),
                "max":    _safe_float(sn.max()),
            }
            for p in (10, 25, 50, 75, 90, 95, 99):
                stats[f"p{p}"] = _safe_float(sn.quantile(p / 100.0))
            stats["skew"] = _safe_float(sn.skew())
            stats["kurt"] = _safe_float(sn.kurt())
            q1, q3 = sn.quantile(.25), sn.quantile(.75)
            iqr = (q3 - q1) if pd.notna(q3) and pd.notna(q1) else None
            if iqr is not None and iqr > 0:
                low, high = q1 - 1.5 * iqr, q3 + 1.5 * iqr
                stats["outlier_threshold_low"] = _safe_float(low)
                stats["outlier_threshold_high"] = _safe_float(high)
                stats["outlier_count"] = int(((sn < low) | (sn > high)).sum())
            analysis["columns"][c] = stats
        elif kind == "categorical":
            vc = s.fillna("(null)").astype(str).value_counts()
            top = vc.head(10)
            total = int(vc.sum()) or 1
            analysis["columns"][c] = {
                "type": "categorical",
                "count": int(s.notna().sum()),
                "unique": int(s.nunique(dropna=True)),
                "null_rate": float(s.isna().mean()),
                "top": [{"value": str(v), "count": int(n), "share": float(n) / total} for v, n in top.items()],
                "top10_share": float(top.sum()) / total,
                "long_tail_count": max(0, int(vc.shape[0]) - 10),
            }
        elif kind == "temporal":
            sd = pd.to_datetime(s, errors="coerce")
            valid = sd.dropna()
            if valid.empty: continue
            analysis["columns"][c] = {
                "type": "temporal",
                "min": valid.min().isoformat(),
                "max": valid.max().isoformat(),
                "span_days": int((valid.max() - valid.min()).days),
                "null_rate": float(s.isna().mean()),
            }
        elif kind == "boolean":
            sb = s.fillna(False).astype(bool)
            analysis["columns"][c] = {
                "type": "boolean",
                "true_count": int(sb.sum()),
                "false_count": int((~sb).sum()),
                "true_rate": float(sb.mean()),
            }

    # Pick primaries
    numerics    = [c for c, k in column_kinds.items() if k == "numeric"]
    categoricals= [c for c, k in column_kinds.items() if k == "categorical"]
    temporals   = [c for c, k in column_kinds.items() if k == "temporal"]

    primary_metric    = max(numerics, key=lambda c: pd.to_numeric(df[c], errors="coerce").abs().sum()) if numerics else None
    primary_dimension = min(categoricals, key=lambda c: df[c].nunique(dropna=True)) if categoricals else None
    primary_temporal  = temporals[0] if temporals else None

    analysis["summary"] = {
        "row_count": int(len(df)),
        "column_count": int(len(df.columns)),
        "time_span_days": analysis["columns"].get(primary_temporal, {}).get("span_days") if primary_temporal else None,
        "primary_metric": primary_metric,
        "primary_dimension": primary_dimension,
        "primary_temporal": primary_temporal,
    }

    # Aggregations: each (categorical, numeric) pair, top 8
    for cat in categoricals:
        for met in numerics:
            try:
                g = df.groupby(cat)[met].agg(["sum", "mean", "count"]).reset_index()
                g = g.sort_values("sum", ascending=False).head(8)
                key = f"by_{_safe_key(cat)}_{_safe_key(met)}"
                analysis["aggregations"][key] = [
                    {"value": str(r[cat]), "sum": _safe_float(r["sum"]),
                     "mean": _safe_float(r["mean"]), "count": int(r["count"])}
                    for _, r in g.iterrows()
                ]
            except Exception:
                continue

    # Time series buckets
    if primary_temporal and numerics:
        for met in numerics:
            try:
                ts_df = df[[primary_temporal, met]].dropna()
                ts_df[primary_temporal] = pd.to_datetime(ts_df[primary_temporal], errors="coerce")
                ts_df = ts_df.dropna()
                if ts_df.empty: continue
                span = (ts_df[primary_temporal].max() - ts_df[primary_temporal].min()).days
                if   span < 3:    bucket = "H"; label = "hour"
                elif span < 90:   bucket = "D"; label = "day"
                elif span < 540:  bucket = "W"; label = "week"
                else:             bucket = "M"; label = "month"
                ts_df["b"] = ts_df[primary_temporal].dt.to_period(bucket).dt.to_timestamp()
                ts = ts_df.groupby("b")[met].sum().reset_index()
                ts["rolling"] = ts[met].rolling(7, min_periods=1).mean()
                key = f"{_safe_key(primary_temporal)}_{_safe_key(met)}"
                analysis["time_series"][key] = {
                    "bucket": label,
                    "points": [{"ts": r["b"].isoformat(), "value": _safe_float(r[met]), "rolling": _safe_float(r["rolling"])} for _, r in ts.iterrows()],
                }
            except Exception:
                continue

    # Correlations
    if len(numerics) >= 2:
        try:
            corr = df[numerics].corr(method="pearson").stack()
            for (a, b), r in corr.items():
                if a >= b: continue
                if pd.isna(r): continue
                if abs(r) >= 0.3:
                    analysis["correlations"].append({"x": a, "y": b, "r": float(r), "n": int(df[[a, b]].dropna().shape[0])})
            analysis["correlations"].sort(key=lambda d: abs(d["r"]), reverse=True)
        except Exception:
            pass

    # Outliers (top 10 by absolute distance from median across numerics)
    out_records = []
    for c in numerics:
        sn = pd.to_numeric(df[c], errors="coerce")
        med = sn.median(); std = sn.std()
        if pd.isna(med) or pd.isna(std) or std == 0: continue
        z = (sn - med) / std
        idx = z.abs().nlargest(10).index
        for i in idx:
            out_records.append({"row_index": int(i), "column": c, "value": _safe_float(sn.loc[i]), "z": _safe_float(z.loc[i])})
    out_records.sort(key=lambda d: abs(d.get("z") or 0), reverse=True)
    analysis["outliers"] = out_records[:10]

    # Insight candidates
    analysis["insights"] = _build_insights(analysis, focus)

    return analysis


def _build_insights(analysis: dict, focus: str) -> list[dict]:
    insights = []
    summary = analysis["summary"]

    # Trend insight
    for key, ts in (analysis.get("time_series") or {}).items():
        pts = ts.get("points") or []
        if len(pts) < 4: continue
        half = len(pts) // 2
        prev = sum(p["value"] or 0 for p in pts[:half])
        curr = sum(p["value"] or 0 for p in pts[half:])
        if prev <= 0: continue
        delta = (curr - prev) / prev
        score = min(abs(delta), 1.0)
        insights.append({
            "rank": 0, "score": score, "type": "trend",
            "headline": f"{key.split('_')[-1]} {'grew' if delta >= 0 else 'fell'} {abs(delta)*100:.1f}% across the period",
            "evidence": {"metric": key.split('_')[-1], "previous": prev, "current": curr, "delta": delta},
        })

    # Concentration insight
    for key, agg in (analysis.get("aggregations") or {}).items():
        if not agg: continue
        total = sum(a.get("sum") or 0 for a in agg)
        if total <= 0: continue
        top_share = (agg[0].get("sum") or 0) / total
        if top_share >= 0.25:
            dim = key.split("_")[1]
            insights.append({
                "rank": 0, "score": float(top_share), "type": "concentration",
                "headline": f"Top {dim} ({agg[0]['value']}) holds {top_share*100:.1f}% of total",
                "evidence": {"dimension": dim, "value": agg[0]['value'], "share": top_share},
            })

    # Outlier insight
    if analysis.get("outliers"):
        top = analysis["outliers"][0]
        insights.append({
            "rank": 0, "score": min(abs(top.get("z") or 0) / 5.0, 1.0), "type": "outlier",
            "headline": f"Unusual value detected in '{top['column']}' (z={top.get('z'):.1f})",
            "evidence": top,
        })

    # Correlation insight
    for corr in (analysis.get("correlations") or [])[:3]:
        insights.append({
            "rank": 0, "score": min(abs(corr["r"]), 1.0), "type": "correlation",
            "headline": f"'{corr['x']}' and '{corr['y']}' correlate (r={corr['r']:+.2f})",
            "evidence": corr,
        })

    # Focus boost
    if focus:
        focus_lower = focus.lower()
        for ins in insights:
            text = (ins.get("headline") or "").lower()
            if any(tok in text for tok in focus_lower.split()):
                ins["score"] = min(1.0, ins["score"] * 1.5)

    insights.sort(key=lambda d: d["score"], reverse=True)
    for i, ins in enumerate(insights, start=1):
        ins["rank"] = i
    return insights


def _mine_text_facts(text: str) -> list[dict]:
    patterns = [
        (re.compile(r"(\d[\d.,]*)\s*%"), "percentage"),
        (re.compile(r"(?:USD|US\$|\$|R\$|€|£)\s*(\d[\d.,]*)"), "currency"),
        (re.compile(r"\b(\d[\d.,]*)\s*(million|billion|thousand|k|M|B|mil|milhões|bilhões|bi)\b", re.IGNORECASE), "magnitude"),
        (re.compile(r"\b(?:Q[1-4]|H[12])\s*\d{2,4}\b"), "period"),
        (re.compile(r"\b(20\d{2})\b"), "year"),
    ]
    facts = []
    for line_no, line in enumerate(text.splitlines(), start=1):
        for pat, kind in patterns:
            for m in pat.finditer(line):
                start = max(0, m.start() - 30); end = min(len(line), m.end() + 30)
                facts.append({
                    "kind": kind,
                    "match": m.group(0),
                    "context": line[start:end].strip(),
                    "line": line_no,
                })
    return facts[:200]


def _safe_float(v) -> float | None:
    try:
        if v is None: return None
        f = float(v)
        if math.isnan(f) or math.isinf(f): return None
        return f
    except Exception:
        return None


def _safe_key(s: str) -> str:
    return re.sub(r"[^A-Za-z0-9_]", "_", str(s))[:60]


if __name__ == "__main__":
    sys.exit(main())
