#!/usr/bin/env python3
"""
databricks_query.py — Read-only Databricks executor for /prisma.

Auto-detects the available Databricks client in this order:
  1. databricks-sql-connector  (preferred)
  2. databricks-sdk
  3. databricks CLI binary on PATH

Usage:
  python databricks_query.py --mode table --table catalog.schema.table --output dataset.json
  python databricks_query.py --mode query --query "SELECT ..." --output dataset.json

Environment variables required:
  DATABRICKS_HOST           e.g. https://adb-...azuredatabricks.net
  DATABRICKS_HTTP_PATH      e.g. /sql/1.0/warehouses/abcd
  DATABRICKS_TOKEN          PAT
  DATABRICKS_CATALOG        (optional default catalog)
  DATABRICKS_SCHEMA         (optional default schema)

Hard rules:
  - Only SELECT statements are accepted. Any DDL/DML is rejected.
  - Identifiers (catalog.schema.table) are validated against an allowlist regex.
  - Default LIMIT 10000; capped at 100000.
  - Credentials are never echoed in output or stderr.
"""
from __future__ import annotations

import argparse
import datetime as _dt
import json
import os
import re
import shutil
import sys
from typing import Any

# ----------------------------------------------------------------------------
# Guardrails
# ----------------------------------------------------------------------------

WRITE_KEYWORDS = re.compile(
    r"\b(INSERT|UPDATE|DELETE|MERGE|DROP|TRUNCATE|ALTER|CREATE|REPLACE|GRANT|"
    r"REVOKE|COPY|LOAD|UNLOAD|CALL|EXECUTE|REFRESH|VACUUM|OPTIMIZE)\b",
    re.IGNORECASE,
)
IDENTIFIER_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
DEFAULT_LIMIT = 10_000
MAX_LIMIT = 100_000


def is_read_only(query: str) -> bool:
    """Return True iff the query contains no write keywords."""
    return WRITE_KEYWORDS.search(query) is None


def validate_identifier(part: str) -> str:
    if not IDENTIFIER_RE.match(part):
        raise ValueError(f"Invalid identifier: {part!r}")
    return part


def parse_three_part(name: str) -> tuple[str | None, str | None, str]:
    """Accept 'table', 'schema.table', or 'catalog.schema.table'."""
    parts = name.split(".")
    if not 1 <= len(parts) <= 3:
        raise ValueError(f"Bad table identifier: {name!r}")
    parts = [validate_identifier(p) for p in parts]
    if len(parts) == 1:
        return None, None, parts[0]
    if len(parts) == 2:
        return None, parts[0], parts[1]
    return parts[0], parts[1], parts[2]


def normalize_query(sql: str) -> str:
    """Strip trailing semicolons; ensure single statement."""
    sql = sql.strip()
    while sql.endswith(";"):
        sql = sql[:-1].rstrip()
    if ";" in sql:
        raise ValueError("Multi-statement queries are not allowed.")
    return sql


def ensure_limit(sql: str, limit: int = DEFAULT_LIMIT) -> str:
    """If no LIMIT clause exists, append one. If existing limit is too high, cap it."""
    m = re.search(r"\bLIMIT\s+(\d+)\b\s*$", sql, re.IGNORECASE)
    if m:
        existing = int(m.group(1))
        if existing > MAX_LIMIT:
            return re.sub(r"\bLIMIT\s+\d+\s*$", f"LIMIT {MAX_LIMIT}", sql, flags=re.IGNORECASE)
        return sql
    return f"{sql} LIMIT {limit}"


# ----------------------------------------------------------------------------
# Connector detection
# ----------------------------------------------------------------------------

class ConnectorMissing(Exception):
    pass


def detect_connector() -> str:
    try:
        import databricks.sql  # noqa: F401
        return "sql-connector"
    except Exception:
        pass
    try:
        from databricks.sdk import WorkspaceClient  # noqa: F401
        return "sdk"
    except Exception:
        pass
    if shutil.which("databricks"):
        return "cli"
    raise ConnectorMissing(
        "No Databricks client found.\n"
        "Install one of:\n"
        "  pip install databricks-sql-connector\n"
        "  pip install databricks-sdk\n"
        "  brew install databricks   (or your platform's CLI installer)\n"
    )


def env_or_die(name: str) -> str:
    val = os.environ.get(name)
    if not val:
        raise SystemExit(
            f"ERROR: Missing required environment variable: {name}\n"
            "Required: DATABRICKS_HOST, DATABRICKS_HTTP_PATH (sql-connector/CLI), DATABRICKS_TOKEN"
        )
    return val


# ----------------------------------------------------------------------------
# Execution backends
# ----------------------------------------------------------------------------

def execute_sql_connector(sql: str) -> tuple[list[dict], list[dict]]:
    """Returns (columns_meta, rows)."""
    from databricks import sql as dbsql

    host = env_or_die("DATABRICKS_HOST").rstrip("/").replace("https://", "").replace("http://", "")
    http_path = env_or_die("DATABRICKS_HTTP_PATH")
    token = env_or_die("DATABRICKS_TOKEN")

    with dbsql.connect(server_hostname=host, http_path=http_path, access_token=token) as conn:
        with conn.cursor() as cur:
            cur.execute(sql)
            desc = cur.description or []
            cols = [{"name": d[0], "type": _coerce_type(d[1]), "comment": None} for d in desc]
            rows_raw = cur.fetchall()
            rows = [_row_to_dict(r, cols) for r in rows_raw]
    return cols, rows


def execute_sdk(sql: str) -> tuple[list[dict], list[dict]]:
    from databricks.sdk import WorkspaceClient
    from databricks.sdk.service.sql import StatementState

    host = env_or_die("DATABRICKS_HOST")
    token = env_or_die("DATABRICKS_TOKEN")
    warehouse_id = (env_or_die("DATABRICKS_HTTP_PATH").rstrip("/").split("/")[-1])

    w = WorkspaceClient(host=host, token=token)
    resp = w.statement_execution.execute_statement(
        warehouse_id=warehouse_id, statement=sql, wait_timeout="50s"
    )
    state = resp.status.state if resp.status else None
    if state and state.value not in ("SUCCEEDED",):
        raise RuntimeError(f"Statement state={state}: {getattr(resp.status, 'error', None)}")

    schema_cols = resp.manifest.schema.columns if (resp.manifest and resp.manifest.schema) else []
    cols = [{"name": c.name, "type": str(c.type_name).lower() if c.type_name else "string", "comment": None} for c in schema_cols]

    data_array = (resp.result.data_array if resp.result else []) or []
    rows = []
    for arr in data_array:
        rows.append({cols[i]["name"]: _coerce_value(v, cols[i]["type"]) for i, v in enumerate(arr)})
    return cols, rows


def execute_cli(sql: str) -> tuple[list[dict], list[dict]]:
    import subprocess
    warehouse_id = env_or_die("DATABRICKS_HTTP_PATH").rstrip("/").split("/")[-1]
    cmd = ["databricks", "sql", "query", "execute",
           "--warehouse-id", warehouse_id, "--query", sql, "--output", "JSON"]
    proc = subprocess.run(cmd, capture_output=True, text=True, check=False)
    if proc.returncode != 0:
        raise RuntimeError(f"databricks CLI failed: {proc.stderr.strip()[:400]}")
    payload = json.loads(proc.stdout or "{}")
    schema = payload.get("manifest", {}).get("schema", {}).get("columns", [])
    cols = [{"name": c.get("name"), "type": (c.get("type_name") or "string").lower(), "comment": None} for c in schema]
    data_array = payload.get("result", {}).get("data_array", []) or []
    rows = [{cols[i]["name"]: _coerce_value(v, cols[i]["type"]) for i, v in enumerate(arr)} for arr in data_array]
    return cols, rows


def _coerce_type(t: Any) -> str:
    if t is None:
        return "string"
    s = str(t).lower()
    if "int" in s: return "integer"
    if "float" in s or "double" in s or "decimal" in s or "number" in s: return "number"
    if "bool" in s: return "boolean"
    if "timestamp" in s or "date" in s or "time" in s: return "timestamp"
    return "string"


def _row_to_dict(row, cols) -> dict:
    out = {}
    for i, c in enumerate(cols):
        v = row[i]
        out[c["name"]] = _coerce_value(v, c["type"])
    return out


def _coerce_value(v, type_hint: str):
    if v is None:
        return None
    if type_hint == "timestamp" and isinstance(v, (_dt.date, _dt.datetime)):
        return v.isoformat()
    if isinstance(v, (bytes, bytearray)):
        try:
            return v.decode("utf-8", errors="replace")
        except Exception:
            return None
    return v


# ----------------------------------------------------------------------------
# Public dispatch
# ----------------------------------------------------------------------------

def run_query(sql: str) -> tuple[list[dict], list[dict]]:
    backend = detect_connector()
    if backend == "sql-connector":
        return execute_sql_connector(sql)
    if backend == "sdk":
        return execute_sdk(sql)
    if backend == "cli":
        return execute_cli(sql)
    raise RuntimeError(f"Unknown backend: {backend}")


def build_table_sql(catalog: str | None, schema: str | None, table: str, limit: int = DEFAULT_LIMIT) -> str:
    parts = []
    if catalog: parts.append(f"`{catalog}`")
    if schema:  parts.append(f"`{schema}`")
    parts.append(f"`{table}`")
    return f"SELECT * FROM {'.'.join(parts)} LIMIT {limit}"


def fetch_table_comments(catalog: str | None, schema: str | None, table: str) -> dict[str, str]:
    """Try to enrich column metadata with comments."""
    if not catalog or not schema:
        return {}
    sql = (
        f"SELECT column_name, comment FROM `{catalog}`.information_schema.columns "
        f"WHERE table_schema = '{schema}' AND table_name = '{table}'"
    )
    try:
        cols, rows = run_query(sql)
        return {r["column_name"]: r["comment"] for r in rows if r.get("comment")}
    except Exception:
        return {}


# ----------------------------------------------------------------------------
# CLI
# ----------------------------------------------------------------------------

def main() -> int:
    ap = argparse.ArgumentParser(description="Read-only Databricks executor.")
    ap.add_argument("--mode", choices=["table", "query"], required=True)
    ap.add_argument("--table", help="catalog.schema.table or schema.table or table")
    ap.add_argument("--query", help="SELECT statement")
    ap.add_argument("--limit", type=int, default=DEFAULT_LIMIT)
    ap.add_argument("--output", required=True, help="Path to write dataset.json")
    args = ap.parse_args()

    out = {
        "source": {
            "type": "databricks",
            "mode": args.mode,
            "table": None,
            "query": None,
            "row_count": 0,
            "fetched_at": _dt.datetime.utcnow().isoformat() + "Z",
            "row_cap_applied": False,
        },
        "columns": [],
        "rows": [],
    }

    if args.mode == "table":
        if not args.table:
            print("ERROR: --table is required in table mode.", file=sys.stderr)
            return 2
        catalog, schema, table = parse_three_part(args.table)
        sql = build_table_sql(catalog, schema, table, args.limit or DEFAULT_LIMIT)
        out["source"]["table"] = ".".join([p for p in (catalog, schema, table) if p])
        comments = fetch_table_comments(catalog, schema, table)
    else:
        if not args.query:
            print("ERROR: --query is required in query mode.", file=sys.stderr)
            return 2
        sql = normalize_query(args.query)
        if not is_read_only(sql):
            print("ERROR: Query rejected — write operations are not permitted.", file=sys.stderr)
            return 3
        sql = ensure_limit(sql, args.limit or DEFAULT_LIMIT)
        out["source"]["query"] = sql
        comments = {}

    try:
        cols, rows = run_query(sql)
    except ConnectorMissing as e:
        print(str(e), file=sys.stderr)
        return 4
    except Exception as e:
        print(f"ERROR: query failed: {e}", file=sys.stderr)
        return 5

    if comments:
        for c in cols:
            if c["name"] in comments and not c.get("comment"):
                c["comment"] = comments[c["name"]]

    if args.mode == "query":
        m = re.search(r"\bLIMIT\s+(\d+)\b\s*$", sql, re.IGNORECASE)
        if m and int(m.group(1)) >= MAX_LIMIT:
            out["source"]["row_cap_applied"] = True

    out["columns"] = cols
    out["rows"] = rows
    out["source"]["row_count"] = len(rows)

    os.makedirs(os.path.dirname(os.path.abspath(args.output)) or ".", exist_ok=True)
    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, default=str)
    print(f"Wrote {args.output}  rows={len(rows)}  cols={len(cols)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
